"""
Módulo de autenticación para la aplicación Hefest.
Gestiona el inicio de sesión, cierre de sesión y permisos de usuario.
"""

import hashlib
import logging
import uuid
import time
from enum import Enum

# Inicializar logger
logger = logging.getLogger(__name__)

class UserRole(Enum):
    """Roles de usuario disponibles en el sistema"""
    ADMIN = "admin"          # Acceso total
    MANAGER = "manager"      # Acceso a todo excepto configuraciones críticas
    STAFF = "staff"          # Acceso a TPV y operaciones básicas
    RECEPTION = "reception"  # Acceso a hospedería
    KITCHEN = "kitchen"      # Acceso a cocina y pedidos
    GUEST = "guest"          # Acceso limitado (para clientes)


class AuthManager:
    """
    Gestor de autenticación para la aplicación.
    Maneja usuarios, sesiones y permisos.
    """
    
    def __init__(self, db_manager=None):
        """
        Inicializa el gestor de autenticación.
        
        Args:
            db_manager: Instancia del gestor de base de datos
        """
        self.db_manager = db_manager
        self.current_user = None
        self.session_token = None
        self.session_expiry = None
        
        # Si no hay gestor de BD, usar usuarios de prueba
        if self.db_manager is None:
            self._setup_test_users()
    
    def _setup_test_users(self):
        """Configura usuarios de prueba para desarrollo"""
        self.test_users = {
            "admin": {
                "id": 1,
                "username": "admin",
                "password_hash": self._hash_password("admin123"),
                "nombre": "Administrador",
                "apellidos": "del Sistema",
                "role": UserRole.ADMIN,
                "active": True
            },
            "manager": {
                "id": 2,
                "username": "manager",
                "password_hash": self._hash_password("manager123"),
                "nombre": "Gerente",
                "apellidos": "Principal",
                "role": UserRole.MANAGER,
                "active": True
            },
            "staff": {
                "id": 3,
                "username": "staff",
                "password_hash": self._hash_password("staff123"),
                "nombre": "Personal",
                "apellidos": "de TPV",
                "role": UserRole.STAFF,
                "active": True
            }
        }
    
    def _hash_password(self, password):
        """
        Genera un hash seguro para la contraseña.
        
        Args:
            password: Contraseña en texto plano
            
        Returns:
            str: Hash de la contraseña
        """
        # En producción sería mejor usar bcrypt, pero para simplicidad usamos SHA-256
        salt = "hefest_salt"  # En producción, usar un salt único por usuario
        return hashlib.sha256((password + salt).encode()).hexdigest()
    
    def login(self, username, password):
        """
        Realiza el inicio de sesión de un usuario.
        
        Args:
            username: Nombre de usuario
            password: Contraseña
            
        Returns:
            bool: True si el login fue exitoso, False en caso contrario
        """
        if self.db_manager:
            # Buscar usuario en la base de datos
            query = "SELECT * FROM empleados WHERE username = ?"
            result = self.db_manager.query(query, (username,))
            if not result:
                logger.warning(f"Intento de login fallido: usuario {username} no encontrado")
                return False
                
            user = result[0]
            password_hash = user["password"]
            
            if self._hash_password(password) != password_hash:
                logger.warning(f"Intento de login fallido: contraseña incorrecta para {username}")
                return False
                
            if not user["active"]:
                logger.warning(f"Intento de login fallido: usuario {username} inactivo")
                return False
                
            # Login exitoso
            self.current_user = {
                "id": user["id"],
                "username": user["username"],
                "nombre": user["nombre"],
                "apellidos": user["apellidos"],
                "role": UserRole(user["rol"]),
                "last_login": time.time()
            }
        else:
            # Modo de desarrollo con usuarios de prueba
            if username not in self.test_users:
                logger.warning(f"Intento de login fallido: usuario {username} no encontrado")
                return False
                
            user = self.test_users[username]
            
            if self._hash_password(password) != user["password_hash"]:
                logger.warning(f"Intento de login fallido: contraseña incorrecta para {username}")
                return False
                
            if not user["active"]:
                logger.warning(f"Intento de login fallido: usuario {username} inactivo")
                return False
            
            # Login exitoso
            self.current_user = {
                "id": user["id"],
                "username": user["username"],
                "nombre": user["nombre"],
                "apellidos": user["apellidos"],
                "role": user["role"],
                "last_login": time.time()
            }
        
        # Generar token de sesión
        self.session_token = str(uuid.uuid4())
        self.session_expiry = time.time() + 8 * 3600  # 8 horas
        
        logger.info(f"Login exitoso para el usuario {username}")
        return True
    
    def logout(self):
        """
        Cierra la sesión del usuario actual.
        """
        if self.current_user:
            logger.info(f"Logout para el usuario {self.current_user['username']}")
            self.current_user = None
            self.session_token = None
            self.session_expiry = None
            return True
        return False
    
    def is_authenticated(self):
        """
        Verifica si hay una sesión activa y válida.
        
        Returns:
            bool: True si hay una sesión válida
        """
        if not self.current_user or not self.session_token or not self.session_expiry:
            return False
          # Verificar si la sesión ha expirado
        if time.time() > self.session_expiry:
            self.logout()
            return False
        
        return True
    
    def has_permission(self, required_role):
        """
        Verifica si el usuario tiene permisos para una acción.
        
        Args:
            required_role: Rol requerido para la acción
            
        Returns:
            bool: True si el usuario tiene permisos
        """
        if not self.is_authenticated() or not self.current_user:
            logger.debug("Permiso denegado: No hay usuario autenticado.")
            return False

        # El administrador tiene todos los permisos
        if self.current_user["role"] == UserRole.ADMIN:
            logger.debug(f"Permiso concedido: Usuario '{self.current_user['username']}' es ADMIN y tiene acceso total.")
            return True

        # El gerente tiene todos los permisos excepto los de admin
        if self.current_user["role"] == UserRole.MANAGER and required_role != UserRole.ADMIN:
            logger.debug(f"Permiso concedido: Usuario '{self.current_user['username']}' es MANAGER y tiene acceso a '{required_role.value}'.")
            return True

        # Para los demás, verificar el rol exacto
        has_permission = self.current_user["role"] == required_role
        logger.debug(f"Evaluando permisos: Usuario '{self.current_user['username']}' con rol '{self.current_user['role'].value}' requiere '{required_role.value}'. Resultado: {has_permission}")
        return has_permission
    
    def get_current_user(self):
        """
        Obtiene la información del usuario actual.
        
        Returns:
            dict: Información del usuario o None si no hay sesión
        """
        if not self.is_authenticated():
            return None
        
        return self.current_user


# Instancia global para usar en toda la aplicación
auth_manager = AuthManager()

__all__ = ["auth_manager"]
