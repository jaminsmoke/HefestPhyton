# Build Tools - Hefest v0.0.10

Herramientas de construcción y testing para el proyecto Hefest.

## 📁 Archivos

### **tox.ini**
Configuración para testing multi-entorno:
- **py310, py311, py312**: Testing en múltiples versiones Python
- **lint**: Linting con flake8 y mypy
- **docs**: Generación de documentación
- **build**: Construcción de paquetes

## 🚀 Uso

### Testing Multi-Python
```bash
# Instalar tox
pip install tox

# Ejecutar todos los entornos
tox

# Solo Python 3.10
tox -e py310

# Solo linting
tox -e lint

# Build de paquetes
tox -e build
```

### Entornos Disponibles
```bash
# Ver entornos configurados
tox -l

# Recrear entorno
tox -r -e py310

# Ejecutar con verbose
tox -v
```

## 📋 Configuración

### Variables de Entorno
- `PYTHONPATH`: Configurado automáticamente
- `TOX_PARALLEL_NO_SPINNER`: Desactiva spinner en CI/CD

### Dependencias
- **testing**: pytest, pytest-cov, pytest-qt
- **linting**: black, flake8, mypy, isort
- **build**: build, wheel, setuptools

---
*Generado automáticamente - Hefest v0.0.10*
