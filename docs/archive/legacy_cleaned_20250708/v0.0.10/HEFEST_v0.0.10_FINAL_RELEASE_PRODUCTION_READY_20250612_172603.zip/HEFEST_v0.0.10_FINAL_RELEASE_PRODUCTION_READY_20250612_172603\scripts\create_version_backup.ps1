param (
    [string]$Version = "v0.0.1",
    [string]$Description = "Backup automático",
    [string]$BackupPath = "..\Hefest_Backups"
)

# Crear carpeta de backup si no existe
if (!(Test-Path -Path $BackupPath)) {
    New-Item -ItemType Directory -Path $BackupPath
}

# Generar nombre de archivo
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$backupFolder = "$BackupPath\Hefest_$Version_$timestamp"
New-Item -ItemType Directory -Path $backupFolder

# Copiar archivos relevantes
Copy-Item -Path "*" -Destination $backupFolder -Recurse -Exclude "__pycache__", "*.log", "*.tmp", ".vscode", ".idea"

# Comprimir el backup
$zipFile = "$backupFolder.zip"
Compress-Archive -Path $backupFolder -DestinationPath $zipFile

# Eliminar carpeta temporal
Remove-Item -Recurse -Force $backupFolder

Write-Host "Backup creado exitosamente: $zipFile"