# Development Configuration - Hefest v0.0.10

Configuraciones específicas para desarrollo del proyecto Hefest.

## 📁 Archivos

### **pyproject.dev.toml**
Configuración específica para desarrollo:
- **Versiones dinámicas** para builds de desarrollo
- **Debug mode** habilitado por defecto
- **Base de datos de desarrollo** separada
- **Hot-reload** de UI configurado

### **.pre-commit-config.yaml**
Hooks de pre-commit para mantener calidad:
- **black**: Formateo automático
- **isort**: Organización de imports
- **flake8**: Linting de código
- **mypy**: Type checking
- **pytest**: Tests automáticos

## 🚀 Uso

### Pre-commit Hooks
```bash
# Instalar hooks
pip install pre-commit
pre-commit install --config development-config/.pre-commit-config.yaml

# Ejecutar manualmente
pre-commit run --all-files

# Actualizar hooks
pre-commit autoupdate
```

### Configuración de Desarrollo
```bash
# Usar configuración de desarrollo
export HEFEST_CONFIG=development-config/pyproject.dev.toml

# Build de desarrollo
python -m build --config-setting=--config-file=development-config/pyproject.dev.toml
```

## 🔧 Configuración

### Pre-commit Hooks Incluidos
- **trailing-whitespace**: Elimina espacios finales
- **end-of-file-fixer**: Asegura nueva línea al final
- **check-yaml/json**: Valida sintaxis
- **black**: Formateo de código
- **isort**: Ordenamiento de imports
- **flake8**: Linting
- **mypy**: Type checking
- **pytest**: Tests unitarios

### Variables de Desarrollo
- `HEFEST_ENV=development`
- `HEFEST_DEBUG=true`
- `HEFEST_DB=data/hefest_dev.db`

---
*Generado automáticamente - Hefest v0.0.10*
