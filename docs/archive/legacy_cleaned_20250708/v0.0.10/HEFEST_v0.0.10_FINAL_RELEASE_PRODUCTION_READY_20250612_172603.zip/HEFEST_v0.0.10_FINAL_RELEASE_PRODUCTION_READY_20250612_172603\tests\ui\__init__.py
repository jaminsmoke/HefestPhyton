"""
Paquete de tests de interfaz de usuario para Hefest

Este paquete contiene tests para componentes de la interfaz gráfica.
"""

__all__ = [
    'test_ui_components'
]
