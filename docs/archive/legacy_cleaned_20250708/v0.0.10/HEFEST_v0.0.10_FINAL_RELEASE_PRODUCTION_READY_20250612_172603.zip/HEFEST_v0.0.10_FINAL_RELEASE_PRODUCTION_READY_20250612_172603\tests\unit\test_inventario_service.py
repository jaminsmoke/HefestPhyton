"""
Tests unitarios para el InventarioService
"""

import unittest
import sys
import os
from unittest.mock import MagicMock, patch
from datetime import datetime, date

# Agregar el directorio del proyecto al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from services.inventario_service import InventarioService, Producto, Proveedor, MovimientoStock, Pedido


class TestInventarioService(unittest.TestCase):
    """Test case para InventarioService"""
    
    def setUp(self):
        """Configuración antes de cada test"""
        # Crear servicio sin db_manager (usará datos de prueba)
        self.inventario_service = InventarioService()
        
        # También crear uno con mock db_manager para tests específicos
        self.mock_db_manager = MagicMock()
        self.inventario_service_with_db = InventarioService(db_manager=self.mock_db_manager)
    
    def test_initialization_without_db(self):
        """Test inicialización sin base de datos"""
        service = InventarioService()
        self.assertIsNotNone(service)
        self.assertIsNone(service.db_manager)
        self.assertIsInstance(service._productos_cache, list)
        self.assertGreater(len(service._productos_cache), 0)  # Debe tener productos de prueba
    
    def test_initialization_with_db(self):
        """Test inicialización con base de datos"""
        mock_db = MagicMock()
        service = InventarioService(db_manager=mock_db)
        self.assertIsNotNone(service)
        self.assertEqual(service.db_manager, mock_db)
    
    def test_get_productos(self):
        """Test obtener lista de productos"""
        productos = self.inventario_service.get_productos()
        
        self.assertIsInstance(productos, list)
        self.assertGreater(len(productos), 0)
          # Verificar estructura del primer producto
        producto = productos[0]
        self.assertIsInstance(producto, Producto)
        self.assertIsNotNone(producto.id)
        self.assertIsNotNone(producto.nombre)
        self.assertIsNotNone(producto.categoria)
        self.assertIsInstance(producto.precio, (int, float))
        self.assertIsInstance(producto.stock_actual, int)
        self.assertIsInstance(producto.stock_minimo, int)
    
    def test_get_producto_by_id(self):
        """Test obtener producto por ID"""
        # Primero obtener un producto real para asegurar que existe
        productos = self.inventario_service.get_productos()
        self.assertGreater(len(productos), 0, "Debe haber productos en el cache")
        
        # Buscar un producto con ID válido
        producto_con_id = None
        for p in productos:
            if p.id is not None:
                producto_con_id = p
                break
        
        self.assertIsNotNone(producto_con_id, "Debe haber al menos un producto con ID")
        
        # Test con ID existente
        producto = self.inventario_service.get_producto_by_id(producto_con_id.id)
        self.assertIsNotNone(producto)
        self.assertEqual(producto.id, producto_con_id.id)
        
        # Test con ID inexistente
        producto_inexistente = self.inventario_service.get_producto_by_id(9999)
        self.assertIsNone(producto_inexistente)
    
    def test_get_categorias(self):
        """Test obtener categorías de productos"""
        categorias = self.inventario_service.get_categorias()
        
        self.assertIsInstance(categorias, list)
        self.assertGreater(len(categorias), 0)
        
        # Verificar que son strings únicos
        for categoria in categorias:
            self.assertIsInstance(categoria, str)
            self.assertGreater(len(categoria), 0)
        
        # Verificar que no hay duplicados
        self.assertEqual(len(categorias), len(set(categorias)))
    
    def test_producto_dataclass_properties(self):
        """Test propiedades de la dataclass Producto"""
        # Producto que necesita reposición
        producto_bajo = Producto(
            id=1,
            nombre="Producto Bajo",
            categoria="Test",
            precio=10.0,
            stock_actual=5,
            stock_minimo=10
        )
        
        self.assertTrue(producto_bajo.necesita_reposicion)
        self.assertEqual(producto_bajo.nivel_stock_porcentaje, 50.0)
        
        # Producto con stock suficiente
        producto_normal = Producto(
            id=2,
            nombre="Producto Normal",
            categoria="Test",
            precio=10.0,
            stock_actual=20,
            stock_minimo=10
        )
        
        self.assertFalse(producto_normal.necesita_reposicion)
        self.assertEqual(producto_normal.nivel_stock_porcentaje, 200.0)
    
    def test_proveedor_dataclass(self):
        """Test dataclass Proveedor"""
        proveedor = Proveedor(
            id=1,
            nombre="Proveedor Test",
            contacto="Juan Pérez",
            telefono="123456789",
            email="test@proveedor.com",
            direccion="Calle Test 123"
        )
        
        self.assertEqual(proveedor.id, 1)
        self.assertEqual(proveedor.nombre, "Proveedor Test")
        self.assertEqual(proveedor.contacto, "Juan Pérez")
        self.assertEqual(proveedor.telefono, "123456789")
        self.assertEqual(proveedor.email, "test@proveedor.com")
        self.assertEqual(proveedor.direccion, "Calle Test 123")
    
    def test_movimiento_stock_dataclass(self):
        """Test dataclass MovimientoStock"""
        movimiento = MovimientoStock(
            id=1,
            producto_id=1,
            producto_nombre="Producto Test",
            tipo="entrada",
            cantidad=10,
            fecha=datetime.now(),
            motivo="Reposición",
            usuario_id=1,
            usuario_nombre="Admin"
        )
        
        self.assertEqual(movimiento.producto_id, 1)
        self.assertEqual(movimiento.tipo, "entrada")
        self.assertEqual(movimiento.cantidad, 10)
        self.assertIsInstance(movimiento.fecha, datetime)
    
    def test_pedido_dataclass(self):
        """Test dataclass Pedido y su propiedad total"""
        lineas_pedido = [
            (1, "Producto 1", 10, 5.0),  # 10 * 5.0 = 50.0
            (2, "Producto 2", 5, 10.0),  # 5 * 10.0 = 50.0
        ]
        
        pedido = Pedido(
            id=1,
            proveedor_id=1,
            proveedor_nombre="Proveedor Test",
            fecha_pedido=datetime.now(),
            estado="pendiente",
            lineas=lineas_pedido
        )
        
        self.assertEqual(pedido.total, 100.0)  # 50.0 + 50.0
        
        # Pedido sin líneas
        pedido_vacio = Pedido(
            id=2,
            proveedor_id=1,
            proveedor_nombre="Proveedor Test",
            fecha_pedido=datetime.now(),
            estado="pendiente"
        )
        
        self.assertEqual(pedido_vacio.total, 0.0)


if __name__ == '__main__':
    unittest.main()