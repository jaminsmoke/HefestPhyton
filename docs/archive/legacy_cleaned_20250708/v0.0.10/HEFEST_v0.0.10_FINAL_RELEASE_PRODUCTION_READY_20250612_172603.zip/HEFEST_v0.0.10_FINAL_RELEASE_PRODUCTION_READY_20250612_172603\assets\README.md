# README - Assets del Proyecto Hefest

Este directorio contiene todos los recursos visuales y de interfaz del proyecto.

## 📁 Estructura de Assets

### 🖼️ **images/**
- `hefest_logo.png` - Logo principal del proyecto (referenciado en README.md)
- `dashboard_preview.png` - Captura del dashboard principal
- `login_screen.png` - Captura de la pantalla de login
- `modules_overview.png` - Vista general de módulos disponibles

### 🎨 **icons/**
- `hefest.ico` - Icono principal para ejecutables Windows
- `app_icon.png` - Icono de la aplicación en diferentes tamaños
- Iconos de módulos y funcionalidades

### 🎨 **styles/**
- `modern_theme.qss` - Hoja de estilos principal
- `animations.css` - Estilos para animaciones
- Temas adicionales y personalizaciones

### 📝 **fonts/**
- Fuentes personalizadas para la interfaz
- Tipografías corporativas

## 🚀 Uso

Los assets son incluidos automáticamente en el empaquetado mediante:
- `MANIFEST.in` - Para distribución pip
- `pyproject.toml` - Para configuración setuptools  
- `scripts/build_exe.py` - Para ejecutables PyInstaller

## 📸 Capturas Pendientes

Para completar la documentación, se necesitan las siguientes capturas:

1. **Logo principal** (`images/hefest_logo.png`)
2. **Dashboard en funcionamiento** (`images/dashboard_preview.png`)
3. **Pantalla de login** (`images/login_screen.png`)
4. **Vista de módulos** (`images/modules_overview.png`)

Estas imágenes son referenciadas en el README.md principal del proyecto.
