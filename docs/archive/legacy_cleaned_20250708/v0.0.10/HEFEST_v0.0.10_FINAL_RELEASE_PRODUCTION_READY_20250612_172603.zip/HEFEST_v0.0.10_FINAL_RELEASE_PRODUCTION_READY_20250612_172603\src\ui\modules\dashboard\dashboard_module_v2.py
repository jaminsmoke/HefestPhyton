"""
Dashboard modular mejorado para Hefest con diseño moderno
Versión refactorizada con componentes organizados y diseño profesional
"""

import logging
from PyQt6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
                           QWidget, QScrollArea, QFrame, QTabWidget, QGridLayout,
                           QMessageBox)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor

from ..base_module import BaseModule
from .metrics_widgets import MetricsSection
from .charts_widgets import ChartsSection
from .alerts_widgets import AlertsSection
from services.dashboard_service import DashboardDataService
from utils.qt_css_compat import purge_modern_css_from_widget_tree

logger = logging.getLogger(__name__)


class CardWidget(QWidget):
    """Widget personalizado de tarjeta con content_layout"""
    
    def __init__(self, title="", subtitle="", parent=None):
        super().__init__(parent)
        self.title = title
        self.subtitle = subtitle
        self.setup_ui()
    
    def setup_ui(self):
        """Configura la interfaz de la tarjeta"""
        self.setStyleSheet("""
            QWidget {
                background: white;
                border-radius: 12px;
                border: 1px solid #e2e8f0;
                padding: 5px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        if self.title:
            title_label = QLabel(self.title)
            title_label.setStyleSheet("""
                QLabel {
                    font-size: 18px;
                    font-weight: 700;
                    color: #0f172a;
                    margin-bottom: 8px;
                }
            """)
            layout.addWidget(title_label)

        if self.subtitle:
            subtitle_label = QLabel(self.subtitle)
            subtitle_label.setStyleSheet("""
                QLabel {
                    font-size: 14px;
                    color: #64748b;
                    margin-bottom: 16px;
                }
            """)
            layout.addWidget(subtitle_label)

        # Crear el contenedor de contenido que será usado por los widgets hijos
        content_container = QWidget()
        self.content_layout = QVBoxLayout(content_container)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(0)
        
        layout.addWidget(content_container)


class DashboardModuleV2(BaseModule):
    """Dashboard modular mejorado con diseño profesional y componentes organizados"""
    
    mesa_clicked = pyqtSignal(int)
    alert_action = pyqtSignal(str, str)  # (acción, contexto)
          
    def __init__(self, db_manager=None, parent=None):
        super().__init__(parent)
        
        # Guardar referencia del db_manager
        self.db_manager = db_manager
        
        # Inicializar servicio de datos
        if db_manager:
            self.dashboard_service = DashboardDataService(db_manager)
        else:
            raise ImportError("DashboardDataServiceSimple is not available. Please provide a valid db_manager.")
        
        # Componentes principales
        self.metrics_section = None
        self.charts_section = None
        self.alerts_section = None
        
        # Timer para actualizaciones automáticas
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.auto_refresh)
        self.update_timer.start(30000)  # Actualizar cada 30 segundos
        
        self.create_ui()
        
        # Aplicar limpieza CSS para compatibilidad con PyQt6
        try:
            purge_modern_css_from_widget_tree(self)
        except Exception as e:
            logger.warning(f"Failed to apply CSS compatibility filter: {e}")
        
    def create_ui(self):
        """Crea la interfaz del dashboard con diseño moderno mejorado"""
        # Aplicar estilos modernos globales
        self.setStyleSheet("""
            QWidget {
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QTabWidget::pane {
                border: none;
                background: #f8fafc;
                border-radius: 12px;
            }
            QTabBar::tab {
                background: #e2e8f0;
                border: 1px solid #cbd5e1;
                border-bottom: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 12px 24px;
                margin-right: 4px;
                font-weight: 600;
                color: #475569;
                min-width: 100px;
            }
            QTabBar::tab:selected {
                background: white;
                color: #0f172a;
                border-color: #cbd5e1;
            }
            QTabBar::tab:hover {
                background: #f1f5f9;
            }
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollBar:vertical {
                border: none;
                background: #f1f5f9;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 4px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: #94a3b8;
            }
        """)

        # Contenedor principal con pestañas
        tabs = QTabWidget()
        tabs.setObjectName("mainTabs")
        
        # Pestañas reorganizadas con el nuevo diseño
        tabs.addTab(self.create_overview_tab(), "📊 Resumen")
        tabs.addTab(self.create_analytics_tab(), "📈 Análisis")
        tabs.addTab(self.create_alerts_tab(), "🔔 Alertas")
        tabs.addTab(self.create_operations_tab(), "⚙️ Operaciones")
        
        self.content_layout.addWidget(tabs)
        self.refresh()

    def create_overview_tab(self):
        """Crea la pestaña de resumen con diseño moderno de grid"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Encabezado moderno
        header = self.create_modern_header()
        layout.addWidget(header)

        # Contenedor con scroll para el contenido principal
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(20)

        # Sistema de grid para las secciones principales
        grid = QGridLayout()
        grid.setSpacing(20)

        # Sección de métricas clave (ocupa 2 columnas)
        metrics_card = self.create_card_widget(
            "📊 Métricas Clave",
            "Indicadores principales de rendimiento"
        )
        self.metrics_section = MetricsSection(self.dashboard_service)
        metrics_card.content_layout.addWidget(self.metrics_section)
        grid.addWidget(metrics_card, 0, 0, 1, 2)

        # Sección de gráficos (ocupa 2 columnas)
        charts_card = self.create_card_widget(
            "📈 Análisis Visual",
            "Gráficos y mapas interactivos"
        )
        self.charts_section = ChartsSection(dashboard_service=self.dashboard_service)
        self.charts_section.mesa_clicked.connect(self.mesa_clicked.emit)
        charts_card.content_layout.addWidget(self.charts_section)
        grid.addWidget(charts_card, 1, 0, 1, 2)

        # Sección de alertas (ocupa 1 columna al lado)
        alerts_card = self.create_card_widget(
            "🔔 Alertas Operativas",
            "Notificaciones y eventos críticos"
        )
        self.alerts_section = AlertsSection(self.dashboard_service)
        self.alerts_section.alert_action_clicked.connect(self.alert_action.emit)
        alerts_card.content_layout.addWidget(self.alerts_section)
        grid.addWidget(alerts_card, 0, 2, 2, 1)

        # Configurar proporciones del grid
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1) 
        grid.setColumnStretch(2, 1)

        content_layout.addLayout(grid)
        scroll.setWidget(content)
        layout.addWidget(scroll)
        
        return widget

    def create_analytics_tab(self):
        """Crea la pestaña de análisis detallado"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Título de la sección
        title_card = self.create_card_widget(
            "📈 Análisis Detallado",
            "Métricas avanzadas y reportes específicos"
        )
        layout.addWidget(title_card)

        # Contenido en desarrollo
        content_card = self.create_card_widget("", "")
        placeholder = QLabel("🚧 Análisis detallado en desarrollo")
        placeholder.setStyleSheet("""
            QLabel {
                font-size: 18px;
                color: #6b7280;
                background: #f9fafb;
                border: 2px dashed #d1d5db;
                border-radius: 12px;
                padding: 60px;
                margin: 20px;
            }
        """)
        placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        content_card.content_layout.addWidget(placeholder)
        layout.addWidget(content_card)

        layout.addStretch()
        return widget

    def create_alerts_tab(self):
        """Crea la pestaña dedicada a alertas"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Header de alertas
        header_card = self.create_card_widget(
            "🔔 Centro de Alertas",
            "Monitoreo y gestión de notificaciones críticas"
        )
        layout.addWidget(header_card)

        # Sección de alertas expandida
        if self.alerts_section:
            alerts_card = self.create_card_widget("", "")
            alerts_card.content_layout.addWidget(self.alerts_section)
            layout.addWidget(alerts_card)

        return widget

    def create_operations_tab(self):
        """Crea la pestaña de operaciones"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # Título
        title_card = self.create_card_widget(
            "⚙️ Panel de Operaciones",
            "Acciones rápidas y configuración del sistema"
        )
        layout.addWidget(title_card)

        # Botones de operaciones
        operations_card = self.create_card_widget("🚀 Acciones Rápidas", "")
        
        buttons_layout = QGridLayout()
        buttons_layout.setSpacing(15)

        # Definir acciones operativas
        operations = [
            ("📝 Nueva Comanda", "#3b82f6", "Crear nueva orden", self.new_order),
            ("📅 Ver Reservas", "#8b5cf6", "Gestionar reservas", self.show_reservations),
            ("📦 Control Stock", "#10b981", "Revisar inventario", self.open_inventory),
            ("📊 Generar Reporte", "#f59e0b", "Crear informe", self.generate_report),
            ("⚙️ Configuración", "#6b7280", "Ajustes del sistema", self.open_settings),
            ("🔄 Actualizar Todo", "#ef4444", "Refrescar datos", self.refresh)
        ]

        for i, (text, color, tooltip, callback) in enumerate(operations):
            btn = QPushButton(text)
            btn.setToolTip(tooltip)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: {color};
                    color: white;
                    border: none;
                    border-radius: 10px;
                    padding: 15px 20px;
                    font-weight: 600;
                    font-size: 14px;
                    min-height: 20px;
                }}
                QPushButton:hover {{
                    background: {self.darken_color(color)};
                }}
                QPushButton:pressed {{
                    background: {self.darken_color(color, 0.7)};
                }}
            """)
            btn.clicked.connect(callback)
            buttons_layout.addWidget(btn, i // 3, i % 3)

        operations_card.content_layout.addLayout(buttons_layout)
        layout.addWidget(operations_card)

        layout.addStretch()
        return widget

    def create_modern_header(self):
        """Crea el header moderno con logo, título y botones de acción"""
        header = QWidget()
        header.setStyleSheet("""
            QWidget {
                background: white;
                border-radius: 12px;
                border: 1px solid #e2e8f0;
                padding: 5px;
            }
        """)
        
        layout = QHBoxLayout(header)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(20)

        # Logo y título
        logo = QLabel("🔥")
        logo.setStyleSheet("font-size: 36px;")
        
        title_layout = QVBoxLayout()
        title_layout.setSpacing(5)
        
        title = QLabel("Dashboard HEFEST")
        title.setStyleSheet("font-size: 24px; font-weight: 700; color: #0f172a;")
        
        subtitle = QLabel("Resumen operativo en tiempo real")
        subtitle.setStyleSheet("font-size: 14px; color: #64748b;")
        
        title_layout.addWidget(title)
        title_layout.addWidget(subtitle)
        
        layout.addWidget(logo)
        layout.addLayout(title_layout)
        layout.addStretch()

        # Botones de acción rápida
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(10)
        
        actions = [
            ("📝 Nueva Comanda", "#3b82f6", self.new_order),
            ("📅 Reservas", "#8b5cf6", self.show_reservations),
            ("📦 Inventario", "#10b981", self.open_inventory),
            ("🔄 Actualizar", "#64748b", self.refresh)
        ]
        
        for text, color, callback in actions:
            btn = QPushButton(text)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: {color};
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 10px 16px;
                    font-weight: 600;
                    font-size: 13px;
                }}
                QPushButton:hover {{
                    background: {self.darken_color(color)};
                }}
                QPushButton:pressed {{
                    background: {self.darken_color(color, 0.7)};
                }}
            """)
            btn.clicked.connect(callback)
            actions_layout.addWidget(btn)        
        layout.addLayout(actions_layout)
        return header

    def create_card_widget(self, title, subtitle):
        """Crea un widget tipo card con título y subtítulo"""
        return CardWidget(title, subtitle)

    def darken_color(self, hex_color, factor=0.8):
        """Oscurece un color HEX para efectos hover"""
        try:
            # Remover el # si está presente
            hex_color = hex_color.lstrip('#')
            
            # Convertir a RGB
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            
            # Aplicar factor de oscurecimiento
            r = int(r * factor)
            g = int(g * factor)
            b = int(b * factor)
            
            # Convertir de vuelta a hex
            return f"#{r:02x}{g:02x}{b:02x}"
        except:
            return hex_color  # Retornar color original si hay error

    def auto_refresh(self):
        """Actualización automática del dashboard"""
        try:
            self.refresh()
        except Exception as e:
            logger.warning(f"Error en actualización automática: {e}")

    def new_order(self):
        """Acción para crear nueva comanda"""
        QMessageBox.information(
            self, 
            "Nueva Comanda", 
            "Función de nueva comanda en desarrollo.\n\nEsta acción redirigiría al módulo TPV."
        )

    def show_reservations(self):
        """Mostrar ventana de reservas"""
        QMessageBox.information(
            self, 
            "Reservas", 
            "Función de reservas en desarrollo.\n\nEsta acción mostraría el módulo de hospedería."
        )

    def open_inventory(self):
        """Abrir módulo de inventario"""
        QMessageBox.information(
            self, 
            "Inventario", 
            "Función de inventario en desarrollo.\n\nEsta acción redirigiría al módulo de inventario."
        )

    def generate_report(self):
        """Generar reporte"""
        QMessageBox.information(
            self, 
            "Generar Reporte", 
            "Función de reportes en desarrollo.\n\nEsta acción abriría el generador de reportes."
        )

    def open_settings(self):
        """Abrir configuración"""
        QMessageBox.information(
            self, 
            "Configuración", 
            "Función de configuración en desarrollo.\n\nEsta acción abriría el panel de configuración."
        )

    def refresh(self):
        """Actualizar datos del dashboard"""
        try:
            if hasattr(self, 'metrics_section') and self.metrics_section:
                self.metrics_section.refresh_all_metrics()
            if hasattr(self, 'charts_section') and self.charts_section:
                self.charts_section.refresh_charts()
            if hasattr(self, 'alerts_section') and self.alerts_section:
                self.alerts_section.refresh_alerts()
        except Exception as e:
            logger.error(f"Error al actualizar dashboard: {e}")

    # Métodos de compatibilidad con versión anterior
    def create_general_view(self):
        """Método de compatibilidad - redirige a create_overview_tab"""
        return self.create_overview_tab()
        
    def create_detailed_analysis(self):
        """Método de compatibilidad - redirige a create_analytics_tab"""
        return self.create_analytics_tab()
        
    def create_alerts_monitoring(self):
        """Método de compatibilidad - redirige a create_alerts_tab"""
        return self.create_alerts_tab()
