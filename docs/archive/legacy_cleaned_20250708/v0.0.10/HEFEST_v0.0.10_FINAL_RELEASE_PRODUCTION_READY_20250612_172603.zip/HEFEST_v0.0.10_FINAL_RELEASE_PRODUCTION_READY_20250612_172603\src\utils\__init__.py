# Archivo para hacer que el directorio sea un paquete Python
# Aquí se importarán utilidades generales

__all__ = []
