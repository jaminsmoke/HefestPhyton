"""
Módulo de Dashboard para Hefest
"""

from .dashboard_module_v2 import DashboardModuleV2
from .metrics_widgets import MetricsCard, MetricsSection
from .charts_widgets import SalesChart, TableMapWidget
from .alerts_widgets import AlertWidget, AlertsSection

__all__ = [
    'DashboardModuleV2',
    'MetricsCard', 
    'MetricsSection',
    'SalesChart',
    'TableMapWidget',
    'AlertWidget',
    'AlertsSection'
]
