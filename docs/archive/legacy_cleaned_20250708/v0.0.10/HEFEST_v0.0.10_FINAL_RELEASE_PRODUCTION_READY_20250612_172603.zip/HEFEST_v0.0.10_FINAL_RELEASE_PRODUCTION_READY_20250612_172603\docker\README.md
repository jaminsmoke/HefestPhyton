# Docker Configuration - Hefest v0.0.10

Este directorio contiene la configuración para containerización del proyecto Hefest.

## 📁 Archivos

### **docker-compose.yml**
Configuración completa del stack de producción:
- **hefest-app**: Aplicación principal
- **hefest-db**: Base de datos PostgreSQL
- **hefest-redis**: Cache Redis
- **hefest-nginx**: Reverse proxy
- **hefest-monitoring**: Prometheus para métricas

### **Dockerfile**
Imagen optimizada multi-stage para la aplicación Hefest:
- **Stage 1 (builder)**: Compilación de dependencias
- **Stage 2 (production)**: Imagen final optimizada
- **Usuario no-root** para seguridad
- **Health checks** configurados

## 🚀 Uso

### Desarrollo Local
```bash
# Ejecutar stack completo
docker-compose up -d

# Solo la aplicación
docker-compose up hefest-app

# Ver logs
docker-compose logs -f hefest-app
```

### Producción
```bash
# Build y deploy
docker-compose -f docker-compose.yml up -d --build

# Escalado
docker-compose up -d --scale hefest-app=3
```

## 🔧 Configuración

### Variables de Entorno
- `HEFEST_ENV=production`
- `POSTGRES_DB=hefest`
- `REDIS_PASSWORD=hefest_redis_password`

### Puertos Expuestos
- **80/443**: Nginx (HTTP/HTTPS)
- **8080**: Hefest App
- **5432**: PostgreSQL
- **6379**: Redis
- **9090**: Prometheus

## 📊 Monitoreo

La configuración incluye Prometheus para monitoreo de métricas:
- CPU/Memoria de contenedores
- Métricas de aplicación
- Alertas automáticas

---
*Generado automáticamente - Hefest v0.0.10*
