"""
Widgets de alertas para el dashboard de Hefest
"""

import logging
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QPushButton, QFrame)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

logger = logging.getLogger(__name__)


class AlertWidget(QFrame):
    """Widget individual para mostrar una alerta"""
    
    action_clicked = pyqtSignal(str)  # Señal cuando se hace clic en la acción
    resolved = pyqtSignal()  # Señal cuando se resuelve la alerta
    
    def __init__(self, icon, text, priority="medium", action_text="Resolver", parent=None):
        super().__init__(parent)
        self.icon = icon
        self.text = text
        self.priority = priority
        self.action_text = action_text
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de la alerta"""
        # Establecer colores según prioridad
        priority_colors = {
            'high': {'bg': '#fee2e2', 'border': '#fecaca', 'text': '#991b1b'},
            'medium': {'bg': '#fffbeb', 'border': '#fed7aa', 'text': '#92400e'},
            'low': {'bg': '#f0f9ff', 'border': '#bae6fd', 'text': '#0c4a6e'},
            'info': {'bg': '#f0f9ff', 'border': '#bae6fd', 'text': '#0c4a6e'}
        }
        
        colors = priority_colors.get(self.priority, priority_colors['medium'])
        
        self.setStyleSheet(f"""
            QFrame {{
                background: {colors['bg']};
                padding: 10px;
                border-radius: 8px;
                border: 1px solid {colors['border']};
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(12)
        
        # Icono
        icon_label = QLabel(self.icon)
        icon_label.setStyleSheet("font-size: 18px;")
        layout.addWidget(icon_label)
        
        # Texto de la alerta
        text_label = QLabel(self.text)
        text_label.setStyleSheet(f"""
            QLabel {{
                font-size: 14px;
                color: {colors['text']};
                font-weight: 500;
            }}
        """)
        text_label.setWordWrap(True)
        layout.addWidget(text_label, 1)
        
        # Botón de acción
        self.action_button = QPushButton(self.action_text)
        self.action_button.setStyleSheet(f"""
            QPushButton {{
                padding: 6px 12px;
                font-size: 12px;
                font-weight: 500;
                background-color: white;
                border: 1px solid {colors['border']};
                border-radius: 6px;
                color: {colors['text']};
            }}
            QPushButton:hover {{
                background-color: {colors['border']};
            }}
            QPushButton:pressed {{
                background-color: {colors['bg']};
            }}
        """)
        
        self.action_button.clicked.connect(self.on_action_clicked)
        layout.addWidget(self.action_button)
        
        # Botón de cerrar (X)
        close_button = QPushButton("✕")
        close_button.setFixedSize(24, 24)
        close_button.setStyleSheet(f"""
            QPushButton {{
                border: none;
                background: transparent;
                color: {colors['text']};
                font-size: 12px;
                font-weight: bold;
                border-radius: 12px;
            }}
            QPushButton:hover {{
                background-color: {colors['border']};
            }}
        """)
        close_button.clicked.connect(self.resolve_alert)
        layout.addWidget(close_button)
        
    def on_action_clicked(self):
        """Maneja el clic en el botón de acción"""
        self.action_clicked.emit(self.action_text)
        
    def resolve_alert(self):
        """Marca la alerta como resuelta"""
        self.resolved.emit()
        
    def update_text(self, new_text):
        """Actualiza el texto de la alerta"""
        self.text = new_text
        # Buscar el QLabel del texto y actualizarlo
        for child in self.findChildren(QLabel):
            if child.text() == self.text:
                child.setText(new_text)
                break


class AlertsSection(QWidget):
    """Sección completa de alertas del dashboard"""
    
    alert_action_clicked = pyqtSignal(str, str)  # (acción, texto_alerta)
    alert_resolved = pyqtSignal(str)  # texto_alerta
    
    def __init__(self, dashboard_service=None, parent=None):
        super().__init__(parent)
        self.dashboard_service = dashboard_service
        self.active_alerts = []
        self.setup_ui()
        self.refresh_alerts()
        
    def setup_ui(self):
        """Configura la interfaz de la sección de alertas"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(20)
        
        # Contenedor de alertas (sin header propio, se usa el del contenedor padre)
        self.alerts_container = QWidget()
        self.alerts_layout = QVBoxLayout(self.alerts_container)
        self.alerts_layout.setSpacing(10)
        self.alerts_layout.setContentsMargins(0, 0, 0, 0)
        
        layout.addWidget(self.alerts_container)
        
        # Mensaje cuando no hay alertas
        self.no_alerts_label = QLabel("✅ No hay alertas pendientes")
        self.no_alerts_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #10b981;
                background: #f0fdf4;
                padding: 20px;
                border-radius: 8px;
                border: 1px solid #bbf7d0;
            }
        """)
        self.no_alerts_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.no_alerts_label.hide()  # Oculto inicialmente
        
        layout.addWidget(self.no_alerts_label)
        
    def load_default_alerts(self):
        """Carga alertas de ejemplo"""
        default_alerts = [
            {
                'icon': '📉',
                'text': 'Stock crítico: Cerveza Mahou (5/20 unidades)',
                'priority': 'high',
                'action': 'Pedir Stock'
            },
            {
                'icon': '⏱️',
                'text': 'Mesa 2 ocupada desde hace más de 2 horas',
                'priority': 'medium',
                'action': 'Ver Mesa'
            },
            {
                'icon': '📅',
                'text': 'Reserva pendiente de confirmación: Mesa 8 (15:30)',
                'priority': 'high',
                'action': 'Confirmar'
            },
            {
                'icon': '🔄',
                'text': 'Backup automático programado en 30 minutos',
                'priority': 'info',
                'action': 'Ver Detalles'
            }
        ]
        
        for alert_data in default_alerts:
            self.add_alert(**alert_data)
            
    def add_alert(self, icon, text, priority="medium", action="Resolver"):
        """Añade una nueva alerta"""
        alert = AlertWidget(icon, text, priority, action)
        
        # Conectar señales
        alert.action_clicked.connect(
            lambda action_text: self.alert_action_clicked.emit(action_text, text)
        )
        alert.resolved.connect(lambda: self.remove_alert(alert))
        
        # Añadir al layout
        self.alerts_layout.addWidget(alert)
        self.active_alerts.append(alert)
        
        # Ocultar mensaje de "no hay alertas"
        self.no_alerts_label.hide()
        
        return alert
        
    def remove_alert(self, alert_widget):
        """Elimina una alerta específica"""
        if alert_widget in self.active_alerts:
            self.active_alerts.remove(alert_widget)
            self.alerts_layout.removeWidget(alert_widget)
            alert_widget.deleteLater()
            
            # Emitir señal de alerta resuelta
            self.alert_resolved.emit(alert_widget.text)
            
            # Mostrar mensaje si no hay más alertas
            if not self.active_alerts:                self.no_alerts_label.show()
                
    def clear_all_alerts(self):
        """Elimina todas las alertas"""
        for alert in self.active_alerts.copy():
            self.remove_alert(alert)
            
    def refresh_alerts(self):
        """Actualiza las alertas obteniendo datos reales del servicio"""
        if not self.dashboard_service:
            logger.warning("DashboardDataService no disponible, usando alertas simuladas")
            self._refresh_with_simulated_alerts()
            return
            
        try:
            # Limpiar alertas actuales
            self.clear_all_alerts()
            
            # Obtener alertas reales del servicio
            alertas_reales = self.dashboard_service.get_alertas_operativas()
            
            # Añadir cada alerta real
            for alerta in alertas_reales:
                self.add_alert(
                    icon=alerta.icono,
                    text=alerta.mensaje,
                    priority=alerta.prioridad,
                    action=alerta.accion
                )
                
        except Exception as e:
            logger.error(f"Error obteniendo alertas reales: {e}")
            self._refresh_with_simulated_alerts()
    
    def _refresh_with_simulated_alerts(self):
        """Fallback: actualiza con alertas simuladas si el servicio falla"""
        import random
        
        # Ejemplo: actualizar la primera alerta si existe
        if self.active_alerts:
            first_alert = self.active_alerts[0]
            new_stock = random.randint(3, 15)
            first_alert.update_text(f'Stock crítico: Cerveza Mahou ({new_stock}/20 unidades)')
            
        # Ejemplo: añadir una nueva alerta aleatoriamente
        if random.choice([True, False]):
            new_alerts = [
                {
                    'icon': '🌡️',
                    'text': f'Temperatura del frigorífico: {random.randint(6, 12)}°C',
                    'priority': 'medium' if random.randint(6, 12) < 8 else 'low',
                    'action': 'Verificar'
                },
                {
                    'icon': '👥',
                    'text': f'Mesa {random.randint(5, 15)} esperando desde hace {random.randint(10, 30)} minutos',
                    'priority': 'medium',
                    'action': 'Atender'
                }
            ]
            
            if len(self.active_alerts) < 6:  # Máximo 6 alertas
                alert_data = random.choice(new_alerts)
                self.add_alert(**alert_data)
                
    def get_alerts_count(self):
        """Retorna el número de alertas activas"""
        return len(self.active_alerts)
        
    def get_high_priority_count(self):
        """Retorna el número de alertas de alta prioridad"""
        return sum(1 for alert in self.active_alerts if alert.priority == 'high')
        
    def add_stock_alert(self, producto, stock_actual, stock_minimo):
        """Añade una alerta específica de stock bajo"""
        text = f'Stock bajo: {producto} ({stock_actual}/{stock_minimo} unidades)'
        priority = 'high' if stock_actual <= stock_minimo * 0.5 else 'medium'
        
        self.add_alert('📦', text, priority, 'Pedir Stock')
        
    def add_table_alert(self, mesa_numero, tiempo_ocupada):
        """Añade una alerta específica de mesa ocupada mucho tiempo"""
        text = f'Mesa {mesa_numero} ocupada desde hace {tiempo_ocupada}'
        priority = 'medium'
        
        self.add_alert('⏱️', text, priority, 'Ver Mesa')
        
    def add_reservation_alert(self, mesa_numero, hora):
        """Añade una alerta de reserva pendiente"""
        text = f'Reserva pendiente: Mesa {mesa_numero} ({hora})'
        priority = 'high'
        
        self.add_alert('📅', text, priority, 'Confirmar')
