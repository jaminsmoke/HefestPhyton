"""
Widgets de métricas para el dashboard de Hefest
"""

import logging
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QHBoxLayout, QWidget
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from ...modern_components import ModernCard

logger = logging.getLogger(__name__)


class MetricsCard(ModernCard):
    """Tarjeta de métrica individual con diseño mejorado"""
    
    value_changed = pyqtSignal(str)
    
    def __init__(self, title, value, change=None, description=None, parent=None):
        super().__init__(parent)
        self.title = title
        self.current_value = value
        self.change = change
        self.description = description
        
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de la tarjeta"""
        self.setMinimumWidth(280)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)
        
        # Contenedor superior con título y valor
        top_container = QVBoxLayout()
        top_container.setSpacing(4)
        
        # Título con icono
        self.title_label = QLabel(self.title)
        self.title_label.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: 500;
                color: #6b7280;
            }
        """)
          # Valor con soporte para animación
        value_container = QHBoxLayout()
        self.value_label = QLabel(self.current_value)
        self.value_label.setStyleSheet("""
            QLabel {
                font-size: 28px;
                font-weight: bold;
                color: #1f2937;
            }
        """)
        value_container.addWidget(self.value_label)
        
        # Indicador de cambio con color dinámico
        if self.change:
            self.change_widget = self.create_change_indicator(self.change)
            value_container.addWidget(self.change_widget)
            value_container.addStretch()
        
        top_container.addWidget(self.title_label)
        top_container.addLayout(value_container)
        layout.addLayout(top_container)
        
        # Descripción con ícono si es relevante
        if self.description:
            self.desc_container = self.create_description()
            layout.addLayout(self.desc_container)
        
        layout.addStretch()
        
        # Añadir efecto hover con información adicional
        self.setToolTip(f"{self.title}\n{self.description or ''}")
    
    def create_change_indicator(self, change):
        """Crea el indicador de cambio con colores dinámicos"""
        is_alert = "Alerta" in change
        is_positive = "+" in change and not is_alert
        is_negative = "-" in change
        
        if is_alert:
            color = "#ef4444"  # Rojo para alertas
            bg_color = "#fef2f2"
        elif is_positive:
            color = "#10b981"  # Verde para positivos
            bg_color = "#f0fdf4"
        elif is_negative:
            color = "#ef4444"  # Rojo para negativos
            bg_color = "#fef2f2"
        else:
            color = "#6366f1"  # Morado/indigo para neutros
            bg_color = "#eef2ff"
            
        change_container = QWidget()
        change_container.setFixedHeight(28)
        change_container.setStyleSheet(f"""
            QWidget {{
                background: {bg_color};
                border-radius: 14px;
                padding: 0 12px;
            }}
        """)
        
        change_layout = QHBoxLayout(change_container)
        change_layout.setContentsMargins(8, 0, 8, 0)
        change_layout.setSpacing(4)
        
        self.change_label = QLabel(change)
        self.change_label.setStyleSheet(f"""
            QLabel {{
                font-size: 14px;
                color: {color};
                font-weight: 500;
            }}
        """)
        change_layout.addWidget(self.change_label)
        
        return change_container
    
    def create_description(self):
        """Crea la descripción con ícono relevante"""
        desc_container = QHBoxLayout()
        desc_container.setSpacing(4)
          # Añadir ícono relevante basado en el texto
        icon_text = "📈" if self.description and "vs." in self.description else "ℹ️"
        icon_label = QLabel(icon_text)
        desc_container.addWidget(icon_label)
        
        self.desc_label = QLabel(self.description)
        self.desc_label.setStyleSheet("""
            QLabel {
                font-size: 13px;
                color: #6b7280;
            }
        """)
        desc_container.addWidget(self.desc_label)
        desc_container.addStretch()
        
        return desc_container
    
    def update_value(self, new_value):
        """Actualiza el valor de la métrica"""
        self.current_value = new_value
        self.value_label.setText(str(new_value))
        self.value_changed.emit(str(new_value))
    
    def update_change(self, new_change):
        """Actualiza el indicador de cambio"""
        if hasattr(self, 'change_label'):
            self.change = new_change
            self.change_label.setText(new_change)
            
            # Actualizar colores
            is_alert = "Alerta" in new_change
            is_positive = "+" in new_change and not is_alert
            is_negative = "-" in new_change
            
            if is_alert:
                color = "#ef4444"
                bg_color = "#fef2f2"
            elif is_positive:
                color = "#10b981"
                bg_color = "#f0fdf4"
            elif is_negative:
                color = "#ef4444"
                bg_color = "#fef2f2"
            else:
                color = "#6366f1"
                bg_color = "#eef2ff"
                
            self.change_widget.setStyleSheet(f"""
                QWidget {{
                    background: {bg_color};
                    border-radius: 14px;
                    padding: 0 12px;
                }}
            """)
            self.change_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 14px;
                    color: {color};
                    font-weight: 500;
                }}
            """)


class MetricsSection(QWidget):
    """Sección completa de métricas del dashboard"""
    
    def __init__(self, dashboard_service=None, parent=None):
        super().__init__(parent)
        self.dashboard_service = dashboard_service
        self.metric_cards = []
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de la sección de métricas"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(20)
        
        # Contenedor de tarjetas (sin header propio, se usa el del contenedor padre)
        from PyQt6.QtWidgets import QGridLayout
        cards_container = QWidget()
        self.grid_layout = QGridLayout(cards_container)
        self.grid_layout.setSpacing(20)
        self.grid_layout.setContentsMargins(0, 0, 0, 0)
        
        # Crear tarjetas iniciales
        self.create_default_cards()
        
        layout.addWidget(cards_container)
    
    def create_default_cards(self):
        """Crea las tarjetas de métricas por defecto"""
        cards_data = [
            ("💰 Ventas Hoy", "2.345,00 €", "+12.5%", "vs. mismo día semana pasada"),
            ("🪑 Ocupación Actual", "24/30", "80%", "Mesas ocupadas"),
            ("⏱ Ticket Promedio", "45,80 €", "+3.2%", "Por comanda"),
            ("📉 Productos Bajos", "8", "¡Alerta!", "Stock crítico"),
            ("📅 Reservas Hoy", "18", "2 VIP", "Confirmadas"),
            ("🔄 Rotación Mesa", "2.8x", "+0.4x", "Veces por día")
        ]
        
        row, col = 0, 0
        max_cols = 3
        
        for title, value, change, description in cards_data:
            card = MetricsCard(title, value, change, description)
            self.metric_cards.append(card)
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col >= max_cols:
                col = 0
                row += 1
    
    def add_metric_card(self, title, value, change=None, description=None):
        """Añade una nueva tarjeta de métrica"""
        card = MetricsCard(title, value, change, description)
        self.metric_cards.append(card)
        
        # Calcular posición en el grid
        row = len(self.metric_cards) // 3
        col = len(self.metric_cards) % 3
        
        self.grid_layout.addWidget(card, row, col)
        return card
    
    def update_metric(self, index, value=None, change=None):
        """Actualiza una métrica específica por índice"""
        if 0 <= index < len(self.metric_cards):
            card = self.metric_cards[index]
            if value is not None:
                card.update_value(value)
            if change is not None:
                card.update_change(change)
    
    def refresh_all_metrics(self):
        """Actualiza todas las métricas con datos reales del servicio"""
        if not self.dashboard_service:
            logger.warning("DashboardDataService no disponible, usando datos simulados")
            self._refresh_with_simulated_data()
            return
            
        try:
            # Obtener todas las métricas reales
            metricas = self.dashboard_service.get_todas_las_metricas()
            
            # Mapear métricas a las tarjetas correspondientes
            metric_mapping = [
                ('ventas_hoy', 0, "💰 Ventas Hoy"),
                ('ocupacion_mesas', 1, "🪑 Ocupación Actual"), 
                ('ticket_promedio', 2, "⏱ Ticket Promedio"),
                ('productos_stock_bajo', 3, "📉 Productos Bajos"),
                ('reservas_hoy', 4, "📅 Reservas Hoy"),
                ('rotacion_mesas', 5, "🔄 Rotación Mesa")
            ]
            
            for metric_key, card_index, title_prefix in metric_mapping:
                if metric_key in metricas and card_index < len(self.metric_cards):
                    metrica = metricas[metric_key]
                    
                    # Formatear valor según el tipo
                    if metrica.formato == "currency":
                        valor_formatted = f"{metrica.valor_actual:,.2f} {metrica.unidad}"
                    elif metrica.formato == "percentage":
                        valor_formatted = f"{metrica.valor_actual:.1f}%"
                    else:
                        valor_formatted = f"{metrica.valor_actual:.1f}{metrica.unidad}"
                    
                    # Determinar el texto del cambio y color
                    cambio_texto = metrica.cambio_texto
                    if "stock" in metric_key.lower() and metrica.valor_actual > 5:
                        cambio_texto = "Normal" if metrica.valor_actual > 10 else "Alerta"
                    
                    # Actualizar la tarjeta
                    self.update_metric(card_index, valor_formatted, cambio_texto)
                
        except Exception as e:
            logger.error(f"Error actualizando métricas reales: {e}")
            self._refresh_with_simulated_data()
    
    def _refresh_with_simulated_data(self):
        """Fallback: actualiza con datos simulados si el servicio falla"""
        try:
            import random
            
            updates = [
                (f"{random.randint(2000, 3000):.2f} €", f"+{random.randint(5, 20)}.{random.randint(0, 9)}%"),
                (f"{random.randint(20, 30)}/30", f"{random.randint(60, 90)}%"),
                (f"{random.randint(40, 60):.2f} €", f"+{random.randint(1, 5)}.{random.randint(0, 9)}%"),
                (str(random.randint(5, 15)), "¡Alerta!" if random.choice([True, False]) else "Normal"),
                (str(random.randint(15, 25)), f"{random.randint(1, 5)} VIP"),
                (f"{random.randint(2, 4)}.{random.randint(0, 9)}x", f"+0.{random.randint(1, 5)}x")
            ]
            
            for i, (value, change) in enumerate(updates):
                self.update_metric(i, value, change)
                
        except Exception as e:
            logger.error(f"Error actualizando métricas simuladas: {e}")
