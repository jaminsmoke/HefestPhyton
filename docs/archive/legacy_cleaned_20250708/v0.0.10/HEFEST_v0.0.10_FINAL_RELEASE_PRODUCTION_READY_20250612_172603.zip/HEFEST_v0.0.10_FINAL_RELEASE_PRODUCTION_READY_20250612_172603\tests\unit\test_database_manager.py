"""
Tests unitarios para el DatabaseManager
"""

import unittest
import sys
import os
import tempfile

# Agregar el directorio del proyecto al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from data.db_manager import DatabaseManager


class TestDatabaseManager(unittest.TestCase):
    """Test case para DatabaseManager"""
    
    def setUp(self):
        """Configuración antes de cada test"""
        # Crear base de datos temporal para tests
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()
        
        # Crear DatabaseManager con path temporal
        self.db_manager = DatabaseManager(path=self.temp_db.name)
    
    def tearDown(self):
        """Limpieza después de cada test"""
        # Eliminar archivo temporal
        try:
            os.unlink(self.temp_db.name)
        except (OSError, FileNotFoundError):
            pass
    
    def test_init_database(self):
        """Test inicialización de base de datos"""
        # Verificar que se crearon las tablas usando el método query
        result = self.db_manager.query("SELECT name FROM sqlite_master WHERE type='table' AND name='usuarios'")
        self.assertIsNotNone(result)
        self.assertEqual(len(result), 1)
        
        # Verificar tabla productos
        result = self.db_manager.query("SELECT name FROM sqlite_master WHERE type='table' AND name='productos'")
        self.assertIsNotNone(result)
        self.assertEqual(len(result), 1)
    
    def test_query_method(self):
        """Test método query para consultas SELECT"""
        # Primero insertar algunos usuarios de prueba
        usuarios_test = [
            {'nombre': 'Admin Test', 'role': 'ADMIN', 'pin': 'admin123', 'email': 'admin@test.com', 'telefono': '123'},
            {'nombre': 'Manager Test', 'role': 'MANAGER', 'pin': 'manager123', 'email': 'manager@test.com', 'telefono': '456'},
            {'nombre': 'Employee Test', 'role': 'EMPLOYEE', 'pin': 'employee123', 'email': 'employee@test.com', 'telefono': '789'}
        ]
        
        for usuario_data in usuarios_test:
            self.db_manager.insert('usuarios', usuario_data)
        
        # Consultar usuarios
        result = self.db_manager.query("SELECT COUNT(*) as count FROM usuarios")
        self.assertIsNotNone(result)
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)
        
        # Verificar que hay usuarios
        count = result[0]['count']
        self.assertGreaterEqual(count, 3)  # Debería haber al menos 3 usuarios de prueba
    
    def test_execute_method(self):
        """Test método execute para operaciones de modificación"""
        # Insertar un producto de prueba
        result = self.db_manager.execute(
            "INSERT INTO productos (nombre, precio, stock, categoria) VALUES (?, ?, ?, ?)",
            ('Test Product', 10.99, 50, 'Test Category')
        )
        
        # Verificar que la inserción fue exitosa
        self.assertTrue(result)
        
        # Verificar que se insertó el producto
        products = self.db_manager.query("SELECT * FROM productos WHERE nombre = 'Test Product'")
        self.assertEqual(len(products), 1)
        self.assertEqual(products[0]['nombre'], 'Test Product')
        self.assertEqual(products[0]['precio'], 10.99)
    
    def test_get_by_id(self):
        """Test método get_by_id"""
        # Insertar usuario de prueba
        self.db_manager.execute(
            "INSERT INTO usuarios (nombre, role, pin, email, telefono, fecha_creacion, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ('Test User', 'employee', '1234', 'test@email.com', '123456789', '2025-06-12', 1)
        )
        
        # Obtener el ID del usuario insertado
        user_result = self.db_manager.query("SELECT id FROM usuarios WHERE nombre = 'Test User'")
        self.assertEqual(len(user_result), 1)
        user_id = user_result[0]['id']
        
        # Usar get_by_id para obtener el usuario
        user = self.db_manager.get_by_id('usuarios', user_id)
        self.assertIsNotNone(user)
        self.assertEqual(user['nombre'], 'Test User')
        self.assertEqual(user['role'], 'employee')
    
    def test_insert_method(self):
        """Test método insert"""
        # Datos del producto
        product_data = {
            'nombre': 'Test Product Insert',
            'precio': 15.50,
            'stock': 100,
            'categoria': 'Test'
        }
        
        # Insertar producto
        product_id = self.db_manager.insert('productos', product_data)
        self.assertIsNotNone(product_id)
        self.assertIsInstance(product_id, int)
        
        # Verificar que se insertó correctamente
        product = self.db_manager.get_by_id('productos', product_id)
        self.assertIsNotNone(product)
        self.assertEqual(product['nombre'], 'Test Product Insert')
        self.assertEqual(product['precio'], 15.50)
    
    def test_update_method(self):
        """Test método update"""
        # Insertar producto primero
        product_data = {
            'nombre': 'Original Product',
            'precio': 10.00,
            'stock': 50,
            'categoria': 'Original'
        }
        product_id = self.db_manager.insert('productos', product_data)
        
        # Actualizar producto
        update_data = {
            'nombre': 'Updated Product',
            'precio': 20.00,
            'stock': 75
        }
        # update() no retorna valor, solo ejecuta la operación
        self.db_manager.update('productos', product_id, update_data)
        
        # Verificar la actualización
        updated_product = self.db_manager.get_by_id('productos', product_id)
        self.assertEqual(updated_product['nombre'], 'Updated Product')
        self.assertEqual(updated_product['precio'], 20.00)
        self.assertEqual(updated_product['stock'], 75)
        self.assertEqual(updated_product['categoria'], 'Original')  # No debería cambiar
    
    def test_delete_method(self):
        """Test método delete"""
        # Insertar producto primero
        product_data = {
            'nombre': 'Product to Delete',
            'precio': 5.00,
            'stock': 10,
            'categoria': 'Delete'
        }
        product_id = self.db_manager.insert('productos', product_data)
        
        # Verificar que existe
        product = self.db_manager.get_by_id('productos', product_id)
        self.assertIsNotNone(product)
        
        # Eliminar producto (delete() no retorna valor, solo ejecuta)
        self.db_manager.delete('productos', product_id)
        
        # Verificar que se eliminó
        deleted_product = self.db_manager.get_by_id('productos', product_id)
        self.assertIsNone(deleted_product)
    
    def test_get_usuarios(self):
        """Test método get_usuarios específico"""
        # Primero insertar usuarios de prueba ya que BD temporal está vacía
        usuarios_test = [
            {'nombre': 'Admin Test', 'role': 'ADMIN', 'pin': 'admin123', 'email': 'admin@test.com', 'telefono': '123', 'is_active': 1},
            {'nombre': 'Manager Test', 'role': 'MANAGER', 'pin': 'manager123', 'email': 'manager@test.com', 'telefono': '456', 'is_active': 1},
            {'nombre': 'Employee Test', 'role': 'EMPLOYEE', 'pin': 'employee123', 'email': 'employee@test.com', 'telefono': '789', 'is_active': 1}
        ]
        
        for usuario_data in usuarios_test:
            self.db_manager.insert('usuarios', usuario_data)
        
        usuarios = self.db_manager.get_usuarios()
        self.assertIsNotNone(usuarios)
        self.assertIsInstance(usuarios, list)
        self.assertGreaterEqual(len(usuarios), 3)  # Usuarios de prueba insertados
          # Verificar estructura de usuarios
        if usuarios:
            first_user = usuarios[0]
            # Verificar que podemos acceder a las propiedades básicas
            self.assertIsNotNone(first_user['id'])
            self.assertIsNotNone(first_user['nombre'])
            self.assertIsNotNone(first_user['role'])
    
    def test_get_usuario_by_id(self):
        """Test método get_usuario_by_id específico"""
        # Insertar un usuario de prueba primero
        usuario_data = {
            'nombre': 'Test User', 
            'role': 'ADMIN', 
            'pin': 'test123', 
            'email': 'test@example.com', 
            'telefono': '123456789',
            'is_active': 1
        }
        user_id = self.db_manager.insert('usuarios', usuario_data)
        
        # Obtener usuario por ID
        usuario = self.db_manager.get_usuario_by_id(user_id)
        self.assertIsNotNone(usuario)
        self.assertEqual(usuario['id'], user_id)
        self.assertEqual(usuario['nombre'], 'Test User')
        
        # Test con ID inexistente
        usuario_inexistente = self.db_manager.get_usuario_by_id(9999)
        self.assertIsNone(usuario_inexistente)
    
    def test_validate_user_login(self):
        """Test validación de login de usuario"""
        # Insertar un usuario de prueba
        usuario_data = {
            'nombre': 'Admin Test', 
            'role': 'ADMIN', 
            'pin': 'admin123', 
            'email': 'admin@test.com', 
            'telefono': '123456789',
            'is_active': 1
        }
        user_id = self.db_manager.insert('usuarios', usuario_data)
        
        # Test login válido
        valid_user = self.db_manager.validate_user_login(user_id, 'admin123')
        self.assertIsNotNone(valid_user)
        self.assertEqual(valid_user['nombre'], 'Admin Test')
        self.assertEqual(valid_user['role'], 'ADMIN')
        
        # Test login inválido (PIN incorrecto)
        invalid_user = self.db_manager.validate_user_login(user_id, 'wrong_pin')
        self.assertIsNone(invalid_user)
        
        # Test con ID de usuario inexistente
        nonexistent_user = self.db_manager.validate_user_login(9999, 'admin123')
        self.assertIsNone(nonexistent_user)
    
    def test_connection_handling(self):
        """Test manejo de conexiones con context manager"""
        # Verificar que podemos realizar múltiples operaciones
        with self.db_manager._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM usuarios")
            count1 = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM productos")
            count2 = cursor.fetchone()[0]
            
            self.assertIsInstance(count1, int)
            self.assertIsInstance(count2, int)


if __name__ == '__main__':
    unittest.main()
