"""
Sistema de Autenticacion Robusto para Hefest
============================================

Este modulo implementa un sistema de autenticacion de doble nivel:
1. Login basico: Acceso al programa
2. User Selector: Autenticacion por roles (Administrador/Manager/Empleado)

Caracteristicas:
- Gestion segura de usuarios y roles
- Autenticacion por PIN
- Sistema de sesiones
- Logging de auditoria
- Validacion de permisos
"""

import hashlib
import logging
import time
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from enum import Enum

from core.models import User, Role

logger = logging.getLogger(__name__)

class AuthenticationError(Exception):
    """Excepcion para errores de autenticacion"""
    pass

class PermissionError(Exception):
    """Excepcion para errores de permisos"""
    pass

@dataclass
class SessionInfo:
    """Informacion de la sesion actual"""
    user_id: int
    username: str
    role: Role
    login_time: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)
    session_token: str = ""
    
    def is_expired(self, timeout_seconds: int = 3600) -> bool:
        """Verifica si la sesion ha expirado (por defecto 1 hora)"""
        return (time.time() - self.last_activity) > timeout_seconds
    
    def update_activity(self):
        """Actualiza el timestamp de la ultima actividad"""
        self.last_activity = time.time()


class AuthService:
    """
    Servicio de autenticacion principal
    
    Maneja:
    - Autenticacion de usuarios (login basico + selector de roles)
    - Gestion de sesiones
    - Verificacion de permisos
    - Usuarios por defecto del sistema
    """
    
    def __init__(self, db_manager=None):
        """
        Inicializa el servicio de autenticacion
        
        Args:
            db_manager: Gestor de base de datos (opcional)
        """
        self.db_manager = db_manager
        self.current_session: Optional[SessionInfo] = None
        self._users_cache: Dict[int, User] = {}
        self._initialize_default_users()
        
        logger.info("AuthService inicializado correctamente")
    
    def _initialize_default_users(self):
        """Inicializa los usuarios por defecto del sistema"""
        self.default_users = [
            User(
                id=1,
                username="admin",
                name="Administrador",
                role=Role.ADMIN,
                password="1234",  # PIN por defecto
                email="admin@hefest.com",
                phone="",
                is_active=True
            ),
            User(
                id=2,
                username="manager", 
                name="Manager",
                role=Role.MANAGER,
                password="1234",  # PIN por defecto
                email="manager@hefest.com",
                phone="",
                is_active=True
            ),
            User(
                id=3,
                username="empleado",
                name="Empleado",
                role=Role.EMPLOYEE,
                password="1234",  # PIN por defecto
                email="empleado@hefest.com", 
                phone="",
                is_active=True
            )
        ]
        
        # Llenar cache con usuarios por defecto
        for user in self.default_users:
            if user.id is not None:
                self._users_cache[user.id] = user
        
        logger.info(f"Inicializados {len(self.default_users)} usuarios por defecto")
    
    @property
    def users(self) -> List[User]:
        """Retorna la lista de todos los usuarios disponibles"""
        if self.db_manager:
            try:
                # Intentar cargar desde BD si esta disponible
                return self._load_users_from_db()
            except Exception as e:
                logger.warning(f"Error cargando usuarios desde BD: {e}")
                logger.info("Usando usuarios por defecto")
        
        return self.default_users
    
    @property
    def current_user(self) -> Optional[User]:
        """Retorna el usuario actual autenticado"""
        if self.current_session:
            return self._users_cache.get(self.current_session.user_id)
        return None
    
    @property
    def is_authenticated(self) -> bool:
        """Verifica si hay un usuario autenticado"""
        return (self.current_session is not None and 
                not self.current_session.is_expired())
    
    def _load_users_from_db(self) -> List[User]:
        """Carga usuarios desde la base de datos"""
        if not self.db_manager:
            return self.default_users
            
        try:
            conn = self.db_manager.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, username, name, role, password, email, phone, is_active 
                FROM users WHERE is_active = 1
            """)
            
            db_users = cursor.fetchall()
            users = []
            
            for db_user in db_users:
                try:
                    # Convertir role string a enum
                    role = Role(db_user['role']) if db_user['role'] else Role.EMPLOYEE
                    
                    user = User(
                        id=db_user['id'],
                        username=db_user['username'],
                        name=db_user['name'],
                        role=role,
                        password=db_user['password'],
                        email=db_user.get('email', ''),
                        phone=db_user.get('phone', ''),
                        is_active=bool(db_user.get('is_active', True))
                    )
                    users.append(user)
                    if user.id is not None:
                        self._users_cache[user.id] = user
                    
                except (ValueError, TypeError) as e:
                    logger.error(f"Error procesando usuario {db_user}: {e}")
                    continue
            
            if not users:
                logger.warning("No se encontraron usuarios en BD, usando por defecto")
                return self.default_users
                
            logger.info(f"Cargados {len(users)} usuarios desde BD")
            return users
            
        except Exception as e:
            logger.error(f"Error cargando usuarios desde BD: {e}")
            return self.default_users
    
    def authenticate_basic_login(self, username: str, password: str) -> bool:
        """
        Autenticacion basica para acceso al programa
        
        Args:
            username: Nombre de usuario
            password: Contraseña
            
        Returns:
            True si la autenticacion es exitosa
        """
        # Por ahora, login basico simple
        # En el futuro se puede expandir para BD o LDAP
        basic_credentials = {
            "hefest": "admin",
            "admin": "admin",
            "usuario": "1234"
        }
        
        if username in basic_credentials and basic_credentials[username] == password:
            logger.info(f"Login basico exitoso para usuario: {username}")
            return True
            
        logger.warning(f"Intento de login basico fallido para usuario: {username}")
        return False
    
    def login(self, user_id: int, pin: str) -> bool:
        """
        Autenticacion especifica por usuario/rol con PIN
        
        Args:
            user_id: ID del usuario
            pin: PIN del usuario
            
        Returns:
            True si la autenticacion es exitosa
        """
        try:
            # Buscar usuario
            user = self.get_user_by_id(user_id)
            if not user:
                logger.warning(f"Intento de login con usuario inexistente: {user_id}")
                return False
            
            # Verificar que el usuario este activo
            if not user.is_active:
                logger.warning(f"Intento de login con usuario inactivo: {user.username}")
                return False
            
            # Verificar PIN (usando password como PIN)
            if not self._verify_pin(user, pin):
                logger.warning(f"PIN incorrecto para usuario: {user.username}")
                return False
            
            # Crear sesion solo si user.id no es None
            if user.id is not None:
                self.current_session = SessionInfo(
                    user_id=user.id,
                    username=user.username,
                    role=user.role,
                    session_token=self._generate_session_token()
                )
                
                logger.info(f"Login exitoso para usuario: {user.username} (Role: {user.role.value})")
                return True
            else:
                logger.error(f"Usuario {user.username} tiene ID None")
                return False
            
        except Exception as e:
            logger.error(f"Error durante login: {e}")
            return False
    
    def logout(self):
        """Cierra la sesion actual"""
        if self.current_session:
            logger.info(f"Logout para usuario: {self.current_session.username}")
            self.current_session = None
        else:
            logger.warning("Intento de logout sin sesion activa")
    
    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """
        Obtiene un usuario por su ID
        
        Args:
            user_id: ID del usuario
            
        Returns:
            Usuario encontrado o None
        """
        # Buscar en cache primero
        if user_id in self._users_cache:
            return self._users_cache[user_id]
        
        # Buscar en la lista de usuarios
        for user in self.users:
            if user.id == user_id:
                self._users_cache[user_id] = user
                return user
        
        return None
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """
        Obtiene un usuario por su username
        
        Args:
            username: Nombre de usuario
            
        Returns:
            Usuario encontrado o None
        """
        for user in self.users:
            if user.username == username:
                return user
        return None
    
    def _verify_pin(self, user: User, pin: str) -> bool:
        """
        Verifica el PIN del usuario
        
        Args:
            user: Usuario a verificar
            pin: PIN ingresado
            
        Returns:
            True si el PIN es correcto
        """
        # Por compatibilidad, usamos password como PIN
        return user.password == pin
    
    def _generate_session_token(self) -> str:
        """Genera un token unico para la sesion"""
        import uuid
        return str(uuid.uuid4())
    
    def has_permission(self, permission: str) -> bool:
        """
        Verifica si el usuario actual tiene un permiso especifico
        
        Args:
            permission: Nombre del permiso a verificar
            
        Returns:
            True si tiene el permiso
        """
        if not self.is_authenticated:
            return False
        
        user = self.current_user
        if not user:
            return False
        
        # Mapeo de permisos por rol
        permissions_map = {
            Role.ADMIN: [
                'all',  # Acceso total
                'user_management', 'system_settings', 'reports', 
                'inventory', 'sales', 'audit', 'hospederia'
            ],
            Role.MANAGER: [
                'reports', 'inventory', 'sales', 'audit', 'hospederia',
                'user_view'  # Solo ver usuarios, no editar
            ],
            Role.EMPLOYEE: [
                'sales', 'inventory_view'  # Solo ventas y ver inventario
            ]
        }
        
        user_permissions = permissions_map.get(user.role, [])
        
        # Admin tiene acceso a todo
        if 'all' in user_permissions:
            return True
            
        return permission in user_permissions
    
    def require_permission(self, permission: str):
        """
        Decorador/funcion que requiere un permiso especifico
        
        Args:
            permission: Permiso requerido
            
        Raises:
            PermissionError: Si no tiene el permiso
        """
        if not self.has_permission(permission):
            current_role = self.current_user.role.value if self.current_user else "Sin autenticar"
            raise PermissionError(
                f"Acceso denegado. Rol actual: {current_role}, Permiso requerido: {permission}"
            )
    
    def update_activity(self):
        """Actualiza la actividad de la sesion actual"""
        if self.current_session:
            self.current_session.update_activity()
    
    def get_session_info(self) -> Dict[str, Any]:
        """
        Retorna informacion de la sesion actual
        
        Returns:
            Diccionario con informacion de la sesion
        """
        if not self.current_session:
            return {"authenticated": False}
        
        user = self.current_user
        return {
            "authenticated": True,
            "user_id": self.current_session.user_id,
            "username": self.current_session.username,
            "user_name": user.name if user else "",
            "role": self.current_session.role.value,
            "login_time": self.current_session.login_time,
            "last_activity": self.current_session.last_activity,
            "session_token": self.current_session.session_token
        }


# Instancia global del servicio de autenticacion
_auth_service_instance = None

def get_auth_service() -> AuthService:
    """
    Obtiene la instancia global del servicio de autenticacion
    
    Returns:
        Instancia del AuthService
    """
    global _auth_service_instance
    if _auth_service_instance is None:
        _auth_service_instance = AuthService()
    return _auth_service_instance
