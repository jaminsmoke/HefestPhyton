"""
Servicio de gestión del Terminal Punto de Venta (TPV).
"""

import logging
from typing import List, Dict, Optional
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class Mesa:
    """Clase de datos para una mesa"""
    id: int
    numero: str
    zona: str  # Comedor, terraza, barra
    estado: str  # libre, ocupada, reservada
    capacidad: int

@dataclass
class Producto:
    """Clase de datos para un producto"""
    id: int
    nombre: str
    precio: float
    categoria: str
    stock_actual: Optional[int] = None
    
@dataclass
class LineaComanda:
    """Clase de datos para una línea de comanda"""
    producto_id: int
    producto_nombre: str
    precio_unidad: float
    cantidad: int
    
    @property
    def total(self) -> float:
        return self.precio_unidad * self.cantidad
    
@dataclass
class Comanda:
    """Clase de datos para una comanda"""
    id: Optional[int]
    mesa_id: int
    fecha_apertura: datetime
    fecha_cierre: Optional[datetime]
    estado: str  # abierta, cerrada, pagada, cancelada
    lineas: List[LineaComanda]
    
    @property
    def total(self) -> float:
        return sum(linea.total for linea in self.lineas)

@dataclass
class MetodoPago:
    """Clase de datos para métodos de pago"""
    tipo: str  # efectivo, tarjeta, transferencia, vales
    monto: float
    referencia: Optional[str] = None

@dataclass
class Descuento:
    """Clase de datos para descuentos"""
    tipo: str  # porcentaje, cantidad_fija
    valor: float
    descripcion: str
    
@dataclass
class Factura:
    """Clase de datos para una factura"""
    id: Optional[int]
    comanda_id: int
    fecha: datetime
    subtotal: float
    descuentos: List[Descuento]
    iva: float
    total: float
    metodos_pago: List[MetodoPago]
    estado: str  # pendiente, pagada, cancelada
    
    @property
    def total_descuentos(self) -> float:
        total = 0
        for desc in self.descuentos:
            if desc.tipo == "porcentaje":
                total += self.subtotal * (desc.valor / 100)
            else:  # cantidad_fija
                total += desc.valor
        return total
    
    @property
    def total_pagado(self) -> float:
        return sum(pago.monto for pago in self.metodos_pago)
    
    @property
    def cambio(self) -> float:
        return max(0, self.total_pagado - self.total)


class TPVService:
    """Servicio para la gestión del TPV"""
    
    def __init__(self, db_manager=None):
        self.db_manager = db_manager
        self._mesas_cache = []
        self._categorias_cache = []
        self._productos_cache = []
        self._comandas_cache = {}  # {mesa_id: Comanda}
        self._next_comanda_id = 1  # ID para comandas
        self._load_datos()
        
    def _load_datos(self):
        """Carga los datos desde la base de datos o crea datos de prueba"""
        if self.db_manager:
            # TODO: Implementar carga desde base de datos
            pass
        else:
            # Datos de prueba
            self._mesas_cache = [
                Mesa(1, "Mesa 1", "Comedor", "libre", 4),
                Mesa(2, "Mesa 2", "Comedor", "ocupada", 4),
                Mesa(3, "Mesa 3", "Comedor", "libre", 2),
                Mesa(4, "Mesa 4", "Comedor", "reservada", 6),
                Mesa(5, "Mesa 5", "Terraza", "libre", 4),
                Mesa(6, "Mesa 6", "Terraza", "libre", 4),
                Mesa(7, "Mesa 7", "Terraza", "ocupada", 2),
                Mesa(8, "Mesa 8", "Terraza", "libre", 2),
                Mesa(9, "Barra 1", "Barra", "ocupada", 2),
                Mesa(10, "Barra 2", "Barra", "libre", 2),
            ]
            
            self._categorias_cache = [
                {"id": 1, "nombre": "Bebidas"},
                {"id": 2, "nombre": "Entrantes"},
                {"id": 3, "nombre": "Platos Principales"},
                {"id": 4, "nombre": "Postres"},
                {"id": 5, "nombre": "Menú del día"}
            ]
            
            self._productos_cache = [
                Producto(1, "Coca Cola", 2.50, "Bebidas"),
                Producto(2, "Agua", 1.50, "Bebidas"),
                Producto(3, "Cerveza", 2.80, "Bebidas"),
                Producto(4, "Vino tinto", 3.50, "Bebidas"),
                Producto(5, "Café", 1.30, "Bebidas"),
                Producto(6, "Zumo", 2.20, "Bebidas"),
                Producto(7, "Té", 1.80, "Bebidas"),
                Producto(8, "Batido", 3.00, "Bebidas"),
                # Entrantes
                Producto(9, "Patatas bravas", 5.50, "Entrantes"),
                Producto(10, "Croquetas", 7.00, "Entrantes"),
                # Platos principales
                Producto(11, "Paella", 12.00, "Platos Principales"),
                Producto(12, "Entrecot", 18.50, "Platos Principales"),
                # Postres
                Producto(13, "Tarta", 4.50, "Postres"),
                Producto(14, "Helado", 3.80, "Postres"),
            ]
            
            # Comandas de prueba para mesas ocupadas
            mesa_ocupada_ids = [mesa.id for mesa in self._mesas_cache if mesa.estado == "ocupada"]
            for mesa_id in mesa_ocupada_ids:
                self._crear_comanda_prueba(mesa_id)
    
    def _crear_comanda_prueba(self, mesa_id: int):
        """Crea una comanda de prueba para una mesa"""
        if mesa_id == 2:  # Mesa 2
            lineas = [
                LineaComanda(1, "Coca Cola", 2.50, 2),
                LineaComanda(3, "Cerveza", 2.80, 1),
                LineaComanda(9, "Patatas bravas", 5.50, 1),
            ]
        elif mesa_id == 7:  # Mesa 7
            lineas = [
                LineaComanda(4, "Vino tinto", 3.50, 1),
                LineaComanda(10, "Croquetas", 7.00, 1),
                LineaComanda(11, "Paella", 12.00, 2),
            ]
        elif mesa_id == 9:  # Barra 1
            lineas = [
                LineaComanda(5, "Café", 1.30, 2),
                LineaComanda(13, "Tarta", 4.50, 1),
            ]
        else:
            lineas = []
        
        comanda = Comanda(
            id=None, 
            mesa_id=mesa_id,
            fecha_apertura=datetime.now(),
            fecha_cierre=None,
            estado="abierta",
            lineas=lineas
        )
        
        self._comandas_cache[mesa_id] = comanda
    
    # === MÉTODOS DE ACCESO A DATOS ===
    
    def get_mesas(self) -> List[Mesa]:
        """Retorna lista de todas las mesas"""
        return self._mesas_cache.copy()
    
    def get_mesa_by_id(self, mesa_id: int) -> Optional[Mesa]:
        """Retorna una mesa por su ID"""
        for mesa in self._mesas_cache:
            if mesa.id == mesa_id:
                return mesa
        return None
    
    def get_categorias(self) -> List[Dict]:
        """Retorna lista de categorías de productos"""
        return self._categorias_cache.copy()
    
    def get_productos_by_categoria(self, categoria_id: int) -> List[Producto]:
        """Retorna productos filtrados por categoría"""
        categoria_nombre = next((cat["nombre"] for cat in self._categorias_cache if cat["id"] == categoria_id), None)
        if not categoria_nombre:
            return []
        
        return [p for p in self._productos_cache if p.categoria == categoria_nombre]
    
    def get_productos(self, texto_busqueda: str = "") -> List[Producto]:
        """Retorna todos los productos, opcionalmente filtrados por texto de búsqueda"""
        if not texto_busqueda:
            return self._productos_cache.copy()
        
        texto_busqueda = texto_busqueda.lower()
        return [p for p in self._productos_cache if texto_busqueda in p.nombre.lower()]
    
    def get_comanda_activa(self, mesa_id: int) -> Optional[Comanda]:
        """Retorna la comanda activa para una mesa, si existe"""
        return self._comandas_cache.get(mesa_id)
      # === MÉTODOS DE NEGOCIO ===
    
    def add_producto_comanda(self, mesa_id: int, producto_id: int, cantidad: int = 1) -> Comanda:
        """Añade un producto a una comanda"""
        # Obtener comanda o crear una nueva
        comanda = self.get_comanda_activa(mesa_id)
        if not comanda:
            comanda = self.crear_comanda(mesa_id)
        
        # Buscar el producto
        producto = next((p for p in self._productos_cache if p.id == producto_id), None)
        if not producto:
            raise ValueError(f"No existe producto con ID {producto_id}")
        
        # Verificar si el producto ya está en la comanda
        for linea in comanda.lineas:
            if linea.producto_id == producto_id:
                linea.cantidad += cantidad
                return comanda
        
        # Si no está, añadir nueva línea
        linea = LineaComanda(
            producto_id=producto.id,
            producto_nombre=producto.nombre,
            precio_unidad=producto.precio,
            cantidad=cantidad
        )
        
        comanda.lineas.append(linea)
        return comanda
    
    def cerrar_comanda(self, mesa_id: int, estado: str = "pagada") -> Optional[Comanda]:
        """Cierra una comanda con el estado especificado (pagada o cancelada)"""
        if estado not in ["pagada", "cancelada"]:
            raise ValueError("Estado de comanda no válido. Debe ser 'pagada' o 'cancelada'")
            
        # Verificar que existe la comanda
        comanda = self.get_comanda_activa(mesa_id)
        if not comanda:
            return None
            
        # Cerrar la comanda
        comanda.fecha_cierre = datetime.now()
        comanda.estado = estado
        
        # Liberar la mesa
        for m in self._mesas_cache:
            if m.id == mesa_id:
                m.estado = "libre"
                break
                
        # Quitar de comandas activas
        self._comandas_cache.pop(mesa_id)
        
        # TODO: Persistir en BD
        
        return comanda
        
    def cambiar_estado_mesa(self, mesa_id: int, nuevo_estado: str) -> bool:
        """Cambia el estado de una mesa"""
        if nuevo_estado not in ["libre", "ocupada", "reservada"]:
            raise ValueError("Estado de mesa no válido")
        
        # Verificar que la mesa existe
        mesa = self.get_mesa_by_id(mesa_id)
        if not mesa:
            return False
        
        # Si pasa de ocupada a otro estado, verificar que no tiene comanda activa
        if mesa.estado == "ocupada" and nuevo_estado != "ocupada":
            if mesa_id in self._comandas_cache:
                raise ValueError("No se puede cambiar el estado de una mesa con comanda activa")
                
        # Cambiar estado
        for m in self._mesas_cache:
            if m.id == mesa_id:
                m.estado = nuevo_estado
                return True
                
        return False
    
    # === MÉTODOS ADICIONALES PARA EL MÓDULO TPV ===
    
    def get_todas_mesas(self) -> List[Mesa]:
        """Retorna todas las mesas disponibles"""
        return self._mesas_cache.copy()
        
    def get_mesa_por_id(self, mesa_id: int) -> Optional[Mesa]:
        """Retorna una mesa por su id"""
        for mesa in self._mesas_cache:
            if mesa.id == mesa_id:
                return mesa
        return None
        
    def get_categorias_productos(self) -> List[str]:
        """Retorna todas las categorías de productos"""
        return [cat["nombre"] for cat in self._categorias_cache]
        
    def get_todos_productos(self) -> List[Producto]:
        """Retorna todos los productos"""
        return self._productos_cache.copy()
        
    def get_productos_por_categoria(self, categoria: str) -> List[Producto]:
        """Retorna productos de una categoría específica"""
        return [p for p in self._productos_cache if p.categoria == categoria]
        
    def get_producto_por_id(self, producto_id: int) -> Optional[Producto]:
        """Retorna un producto por su ID"""
        for producto in self._productos_cache:
            if producto.id == producto_id:
                return producto
        return None
        
    def get_comandas_activas(self) -> List[Comanda]:
        """Retorna todas las comandas activas"""
        return list(self._comandas_cache.values())
        
    def get_comanda_por_id(self, comanda_id: int) -> Optional[Comanda]:
        """Retorna una comanda por su ID"""
        for comanda in self._comandas_cache.values():
            if comanda.id == comanda_id:
                return comanda
        return None
        
    def agregar_producto_a_comanda(self, comanda_id: int, producto_id: int, 
                                  producto_nombre: str, precio: float, cantidad: int) -> bool:
        """Agrega un producto a una comanda existente"""
        comanda = self.get_comanda_por_id(comanda_id)
        if not comanda:
            return False
            
        # Verificar si ya existe el producto en la comanda
        for linea in comanda.lineas:
            if linea.producto_id == producto_id:
                linea.cantidad += cantidad
                return True
                
        # Si no existe, añadir una nueva línea
        nueva_linea = LineaComanda(
            producto_id=producto_id,
            producto_nombre=producto_nombre,
            precio_unidad=precio,
            cantidad=cantidad
        )
        
        comanda.lineas.append(nueva_linea)
        return True
        
    def eliminar_producto_de_comanda(self, comanda_id: int, producto_id: int) -> bool:
        """Elimina un producto de una comanda"""
        comanda = self.get_comanda_por_id(comanda_id)
        if not comanda:
            return False
            
        # Buscar el producto en las líneas
        nueva_lineas = []
        eliminado = False
        for linea in comanda.lineas:
            if linea.producto_id != producto_id:
                nueva_lineas.append(linea)
            else:
                eliminado = True
                
        if eliminado:
            comanda.lineas = nueva_lineas
            return True
        return False
        
    def cambiar_cantidad_producto(self, comanda_id: int, producto_id: int, nueva_cantidad: int) -> bool:
        """Cambia la cantidad de un producto en una comanda"""
        if nueva_cantidad <= 0:
            return self.eliminar_producto_de_comanda(comanda_id, producto_id)
            
        comanda = self.get_comanda_por_id(comanda_id)
        if not comanda:
            return False
            
        for linea in comanda.lineas:
            if linea.producto_id == producto_id:
                linea.cantidad = nueva_cantidad
                return True
                
        return False
        
    def crear_comanda(self, mesa_id: int) -> Comanda:
        """Crea una nueva comanda para una mesa"""
        # Verificar que la mesa existe
        mesa = self.get_mesa_por_id(mesa_id)
        if not mesa:
            raise ValueError(f"No existe mesa con ID {mesa_id}")
            
        # Si ya hay una comanda activa, retornarla
        if mesa_id in self._comandas_cache:
            return self._comandas_cache[mesa_id]
        
        # Crear nueva comanda
        comanda_id = self._next_comanda_id
        self._next_comanda_id += 1
        
        comanda = Comanda(
            id=comanda_id,
            mesa_id=mesa_id,
            fecha_apertura=datetime.now(),
            fecha_cierre=None,
            estado="abierta",
            lineas=[]
        )
        
        # Marcar mesa como ocupada y guardar comanda
        for m in self._mesas_cache:
            if m.id == mesa_id:
                m.estado = "ocupada"
                break
                
        self._comandas_cache[mesa_id] = comanda
        return comanda
        
    def guardar_comanda(self, comanda_id: int) -> bool:
        """Guarda una comanda (simulado)"""
        comanda = self.get_comanda_por_id(comanda_id)
        if not comanda:
            return False
            
        # En una implementación real, persistiríamos en la BD
        logger.info(f"Guardando comanda {comanda_id} con {len(comanda.lineas)} líneas")
        return True
        
    def pagar_comanda(self, comanda_id: int) -> bool:
        """Procesa el pago de una comanda"""
        comanda = self.get_comanda_por_id(comanda_id)
        if not comanda:
            return False
            
        # Marcar como pagada
        comanda.estado = "pagada"
        comanda.fecha_cierre = datetime.now()
        
        # En una implementación real, persistiríamos en la BD y procesaríamos el pago
        logger.info(f"Comanda {comanda_id} pagada por un total de {comanda.total}€")
        
        # Mantener la comanda en memoria hasta que se libere la mesa
        return True
        
    def liberar_mesa(self, mesa_id: int) -> bool:
        """Libera una mesa y elimina su comanda"""
        # Verificar que existe la mesa
        mesa = self.get_mesa_por_id(mesa_id)
        if not mesa:
            return False
            
        # Cambiar estado y eliminar comanda
        for m in self._mesas_cache:
            if m.id == mesa_id:
                m.estado = "libre"
                break
                
        if mesa_id in self._comandas_cache:
            del self._comandas_cache[mesa_id]
            
        return True
