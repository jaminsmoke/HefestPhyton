"""
Paquete de tests de integración para Hefest

Este paquete contiene tests que verifican la interacción entre múltiples componentes del sistema.
"""

__all__ = [
    'test_user_inventory_integration'
]
