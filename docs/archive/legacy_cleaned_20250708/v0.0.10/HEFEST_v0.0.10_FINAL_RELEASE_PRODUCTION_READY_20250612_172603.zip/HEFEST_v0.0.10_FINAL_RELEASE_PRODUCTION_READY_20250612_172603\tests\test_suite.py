"""
Suite de Tests Principal para Hefest

Este archivo permite ejecutar todos los tests del proyecto usando unittest.
Uso: python -m tests.test_suite
"""

import unittest
import sys
import os

# Agregar el directorio src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Importar todos los módulos de test
from tests.unit.test_auth_service import TestAuthService
# from tests.unit.test_database_manager import TestDatabaseManager  # Temporalmente comentado
from tests.unit.test_models import (TestRole, TestUser, TestProducto, TestMesa, TestReserva)
from tests.unit.test_inventario_service import TestInventarioService
from tests.integration.test_user_inventory_integration import (
    TestUserInventoryIntegration, 
    TestDatabaseIntegration, 
    TestSystemWorkflow
)
# from tests.ui.test_ui_components import (
#     TestModernSidebar, 
#     TestUserSelector, 
#     TestUIIntegration, 
#     TestUIAccessibility
# )


def create_test_suite():
    """Crea la suite de tests completa"""
    suite = unittest.TestSuite()
      # Tests unitarios
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestAuthService))
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestDatabaseManager))  # Temporalmente comentado
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestRole))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUser))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestProducto))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestMesa))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestReserva))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestInventarioService))
      # Tests de integración
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUserInventoryIntegration))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestDatabaseIntegration))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestSystemWorkflow))
      # Tests de UI - temporalmente comentados (archivo vacío)
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestModernSidebar))
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUserSelector))
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUIIntegration))
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUIAccessibility))
    
    return suite


def run_tests():
    """Ejecuta todos los tests"""
    runner = unittest.TextTestRunner(verbosity=2)
    suite = create_test_suite()
    result = runner.run(suite)
    
    return result.wasSuccessful()


def run_unit_tests_only():
    """Ejecuta solo los tests unitarios"""
    suite = unittest.TestSuite()
    
    # Solo tests unitarios
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestAuthService))
    # suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestDatabaseManager))  # Temporalmente comentado
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestRole))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUser))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestProducto))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestMesa))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestReserva))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestInventarioService))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


def run_integration_tests_only():
    """Ejecuta solo los tests de integración"""
    suite = unittest.TestSuite()
    
    # Solo tests de integración
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestUserInventoryIntegration))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestDatabaseIntegration))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestSystemWorkflow))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


def run_ui_tests_only():
    """Ejecuta solo los tests de UI - temporalmente deshabilitado"""
    print("⚠️  Tests de UI temporalmente deshabilitados (archivo vacío)")
    return True


if __name__ == '__main__':
    print("🧪 Ejecutando Suite de Tests de Hefest")
    print("=" * 50)
    
    if len(sys.argv) > 1:
        test_type = sys.argv[1].lower()
        
        if test_type == 'unit':
            print("Ejecutando solo tests unitarios...")
            success = run_unit_tests_only()
        elif test_type == 'integration':
            print("Ejecutando solo tests de integración...")
            success = run_integration_tests_only()
        elif test_type == 'ui':
            print("Ejecutando solo tests de UI...")
            success = run_ui_tests_only()
        else:
            print("Tipo de test no reconocido. Ejecutando todos los tests...")
            success = run_tests()
    else:
        print("Ejecutando todos los tests...")
        success = run_tests()
    
    print("=" * 50)
    if success:
        print("✅ Todos los tests pasaron exitosamente!")
        sys.exit(0)
    else:
        print("❌ Algunos tests fallaron.")
        sys.exit(1)
