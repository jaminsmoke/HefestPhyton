"""
Tests unitarios para los modelos del core
"""

import unittest
import sys
import os

# Agregar el directorio src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from core.models import User, Role, Producto, Mesa, Reserva
from datetime import datetime, date


class TestRole(unittest.TestCase):
    """Test case para Role enum"""
    
    def test_role_values(self):
        """Test valores del enum Role"""
        self.assertEqual(Role.EMPLOYEE.value, 'employee')
        self.assertEqual(Role.MANAGER.value, 'manager')
        self.assertEqual(Role.ADMIN.value, 'admin')
    
    def test_role_hierarchy(self):
        """Test jerarquía de roles"""
        # Employee es el nivel más bajo
        self.assertEqual(Role.EMPLOYEE.value, 'employee')
        
        # Manager está por encima de Employee
        self.assertEqual(Role.MANAGER.value, 'manager')
        
        # Admin es el nivel más alto
        self.assertEqual(Role.ADMIN.value, 'admin')


class TestUser(unittest.TestCase):
    """Test case para modelo User"""
    
    def test_user_creation(self):
        """Test creación de usuario"""
        user = User(
            id=1,
            username='test_user',
            password='test_pass',
            name='Test User',
            role=Role.EMPLOYEE
        )
        
        self.assertEqual(user.id, 1)
        self.assertEqual(user.username, 'test_user')
        self.assertEqual(user.password, 'test_pass')
        self.assertEqual(user.name, 'Test User')
        self.assertEqual(user.role, Role.EMPLOYEE)
    
    def test_user_string_representation(self):
        """Test representación como string del usuario"""
        user = User(
            id=1,
            username='admin',
            password='pass',
            name='Administrator',
            role=Role.ADMIN
        )
        
        expected = "User(username='admin', name='Administrator', role=Role.ADMIN)"
        self.assertEqual(str(user), expected)
    
    def test_user_equality(self):
        """Test igualdad entre usuarios"""
        user1 = User(1, 'user', 'pass', 'User One', Role.EMPLOYEE)
        user2 = User(1, 'user', 'pass', 'User One', Role.EMPLOYEE)
        user3 = User(2, 'user2', 'pass', 'User Two', Role.MANAGER)
        
        # Usuarios con mismo ID deben ser iguales
        self.assertEqual(user1, user2)
        
        # Usuarios con diferente ID deben ser diferentes
        self.assertNotEqual(user1, user3)
    
    def test_user_role_types(self):
        """Test diferentes tipos de roles en usuarios"""
        employee = User(1, 'emp', 'pass', 'Employee', Role.EMPLOYEE)
        manager = User(2, 'mgr', 'pass', 'Manager', Role.MANAGER)
        admin = User(3, 'admin', 'pass', 'Admin', Role.ADMIN)
        
        self.assertEqual(employee.role, Role.EMPLOYEE)
        self.assertEqual(manager.role, Role.MANAGER)
        self.assertEqual(admin.role, Role.ADMIN)


class TestProducto(unittest.TestCase):
    """Test case para modelo Producto"""
    
    def test_producto_creation(self):
        """Test creación de producto"""
        producto = Producto(
            id=1,
            nombre='Test Product',
            categoria='Test Category',
            precio=15.99,
            stock_actual=100,
            stock_minimo=10,
            proveedor_nombre='Test Supplier'
        )
        
        self.assertEqual(producto.id, 1)
        self.assertEqual(producto.nombre, 'Test Product')
        self.assertEqual(producto.categoria, 'Test Category')
        self.assertEqual(producto.precio, 15.99)
        self.assertEqual(producto.stock_actual, 100)
        self.assertEqual(producto.stock_minimo, 10)
        self.assertEqual(producto.proveedor_nombre, 'Test Supplier')
    
    def test_producto_stock_methods(self):
        """Test métodos relacionados con stock"""
        producto = Producto(
            id=1,
            nombre='Test Product',
            categoria='Test Category',
            precio=15.99,
            stock_actual=5,
            stock_minimo=10,
            proveedor_nombre='Test Supplier'
        )
        
        # Test stock bajo mínimo
        self.assertTrue(producto.is_stock_low())
        
        # Aumentar stock
        producto.stock_actual = 20
        self.assertFalse(producto.is_stock_low())
    
    def test_producto_string_representation(self):
        """Test representación como string del producto"""
        producto = Producto(
            id=1,
            nombre='Test Product',
            categoria='Test Category',
            precio=15.99,
            stock_actual=100,
            stock_minimo=10,
            proveedor_nombre='Test Supplier'
        )
        
        expected = "Producto(id=1, nombre='Test Product', stock=100)"
        self.assertEqual(str(producto), expected)
    
    def test_producto_with_none_values(self):
        """Test producto con valores None"""
        producto = Producto(
            id=None,
            nombre='New Product',
            categoria='Category',
            precio=10.0,
            stock_actual=0,
            stock_minimo=5,
            proveedor_nombre=None
        )
        
        self.assertIsNone(producto.id)
        self.assertIsNone(producto.proveedor_nombre)
        self.assertEqual(producto.nombre, 'New Product')


class TestMesa(unittest.TestCase):
    """Test case para modelo Mesa"""
    
    def test_mesa_creation(self):
        """Test creación de mesa"""
        mesa = Mesa(
            id=1,
            numero=5,
            capacidad=4,
            estado='libre',
            ubicacion='terraza'
        )
        
        self.assertEqual(mesa.id, 1)
        self.assertEqual(mesa.numero, 5)
        self.assertEqual(mesa.capacidad, 4)
        self.assertEqual(mesa.estado, 'libre')
        self.assertEqual(mesa.ubicacion, 'terraza')
    
    def test_mesa_estados(self):
        """Test diferentes estados de mesa"""
        mesa = Mesa(1, 1, 4, 'libre', 'interior')
        
        # Test estado libre
        self.assertTrue(mesa.is_available())
        
        # Cambiar a ocupada
        mesa.estado = 'ocupada'
        self.assertFalse(mesa.is_available())
        
        # Cambiar a reservada
        mesa.estado = 'reservada'
        self.assertFalse(mesa.is_available())
    
    def test_mesa_string_representation(self):
        """Test representación como string de la mesa"""
        mesa = Mesa(1, 5, 4, 'libre', 'terraza')
        
        expected = "Mesa(numero=5, capacidad=4, estado='libre')"
        self.assertEqual(str(mesa), expected)


class TestReserva(unittest.TestCase):
    """Test case para modelo Reserva"""
    
    def test_reserva_creation(self):
        """Test creación de reserva"""
        fecha_reserva = date(2025, 6, 15)
        reserva = Reserva(
            id=1,
            mesa_id=5,
            cliente_nombre='Juan Pérez',
            cliente_telefono='123456789',
            fecha_reserva=fecha_reserva,
            hora_reserva='20:00',
            numero_personas=4,
            estado='confirmada',
            notas='Cumpleaños'
        )
        
        self.assertEqual(reserva.id, 1)
        self.assertEqual(reserva.mesa_id, 5)
        self.assertEqual(reserva.cliente_nombre, 'Juan Pérez')
        self.assertEqual(reserva.cliente_telefono, '123456789')
        self.assertEqual(reserva.fecha_reserva, fecha_reserva)
        self.assertEqual(reserva.hora_reserva, '20:00')
        self.assertEqual(reserva.numero_personas, 4)
        self.assertEqual(reserva.estado, 'confirmada')
        self.assertEqual(reserva.notas, 'Cumpleaños')
    
    def test_reserva_estados(self):
        """Test diferentes estados de reserva"""
        reserva = Reserva(
            id=1,
            mesa_id=1,
            cliente_nombre='Test',
            cliente_telefono='123',
            fecha_reserva=date.today(),
            hora_reserva='20:00',
            numero_personas=2,
            estado='pendiente',
            notas=None
        )
        
        # Test estado pendiente
        self.assertFalse(reserva.is_confirmed())
        
        # Confirmar reserva
        reserva.estado = 'confirmada'
        self.assertTrue(reserva.is_confirmed())
        
        # Cancelar reserva
        reserva.estado = 'cancelada'
        self.assertFalse(reserva.is_confirmed())
        self.assertTrue(reserva.is_cancelled())
    
    def test_reserva_string_representation(self):
        """Test representación como string de la reserva"""
        fecha = date(2025, 6, 15)
        reserva = Reserva(
            id=1,
            mesa_id=5,
            cliente_nombre='Juan Pérez',
            cliente_telefono='123456789',
            fecha_reserva=fecha,
            hora_reserva='20:00',
            numero_personas=4,
            estado='confirmada',
            notas=None
        )
        
        expected = "Reserva(cliente='Juan Pérez', mesa=5, fecha='2025-06-15 20:00')"
        self.assertEqual(str(reserva), expected)
    
    def test_reserva_with_none_values(self):
        """Test reserva con valores opcionales None"""
        reserva = Reserva(
            id=None,
            mesa_id=1,
            cliente_nombre='Test Client',
            cliente_telefono=None,
            fecha_reserva=date.today(),
            hora_reserva='19:00',
            numero_personas=2,
            estado='pendiente',
            notas=None
        )
        
        self.assertIsNone(reserva.id)
        self.assertIsNone(reserva.cliente_telefono)
        self.assertIsNone(reserva.notas)
        self.assertEqual(reserva.cliente_nombre, 'Test Client')


if __name__ == '__main__':
    unittest.main()
