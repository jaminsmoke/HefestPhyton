# 🏨 HEFEST - Scripts de Instalación y Empaquetado

## 📦 Instalación como Paquete Python

### Instalación básica
```bash
# Desde código fuente
pip install -e .

# Con dependencias de desarrollo  
pip install -e .[dev]

# Con herramientas de build
pip install -e .[build]

# Instalación completa
pip install -e .[all]
```

### Verificar instalación
```bash
# Ejecutar desde línea de comandos
hefest

# O ejecutar interfaz gráfica
hefest-gui

# Ejecutar tests
pytest tests/ -v
```

## 🔧 Generar Ejecutable (.exe)

### Opción 1: PyInstaller (Recomendado)
```bash
# Instalar PyInstaller
pip install PyInstaller

# Ejecutable básico
python scripts/build_exe.py

# Ejecutable único (un solo archivo)
python scripts/build_exe.py --onefile

# Sin ventana de consola
python scripts/build_exe.py --windowed

# Limpiar y generar
python scripts/build_exe.py --clean --onefile --windowed
```

### Opción 2: Auto-py-to-exe (GUI)
```bash
# Instalar herramienta
pip install auto-py-to-exe

# Abrir interfaz gráfica
auto-py-to-exe

# Configurar:
# - Script Location: main.py
# - Onefile: Yes
# - Console Window: Window Based (hide console)
# - Icon: assets/icons/hefest.ico
# - Additional Files: data/, assets/, config/
```

### Opción 3: cx_Freeze
```bash
# Instalar cx_Freeze
pip install cx_Freeze

# Crear setup_cx.py y ejecutar
python setup_cx.py build
```

## 📋 Requisitos del Sistema

### Para Desarrollo
- Python 3.10 o superior
- PyQt6 >= 6.5.0
- Memoria: 2GB RAM mínimo
- Espacio: 500MB disponible

### Para Distribución
- PyInstaller >= 5.10.0 (para .exe)
- Inno Setup (para instalador Windows)
- 7-Zip (para comprimir releases)

## 🎯 Distribución

### Crear Release
```bash
# 1. Actualizar versión en pyproject.toml
# 2. Generar ejecutable
python scripts/build_exe.py --clean --onefile --windowed

# 3. Comprimir para distribución  
cd dist
7z a HEFEST-v0.0.10-windows.zip HEFEST.exe

# 4. Crear instalador (opcional)
# Usar Inno Setup con el ejecutable generado
```

### Estructura de Release
```
HEFEST-v0.0.10/
├── HEFEST.exe                  # Ejecutable principal
├── README.md                   # Instrucciones
├── LICENSE                     # Licencia MIT
├── CHANGELOG.md                # Cambios de versión
└── assets/                     # Recursos (si es necesario)
    ├── icons/
    └── config/
```

## 🔍 Solución de Problemas

### Error: "No module named PyQt6"
```bash
# Reinstalar PyQt6
pip uninstall PyQt6
pip install PyQt6>=6.5.0
```

### Error: "Cannot find main.py"
```bash
# Verificar ruta
cd /ruta/a/hefest
ls main.py  # Debe existir

# Ejecutar desde directorio correcto
python main.py
```

### Ejecutable muy grande
```bash
# Usar UPX para comprimir (opcional)
pip install upx-python
python scripts/build_exe.py --onefile

# El ejecutable se comprimirá automáticamente
```

### Problemas con iconos/recursos
```bash
# Verificar que los archivos existan
ls assets/icons/hefest.ico
ls data/hefest.db

# Regenerar con todos los datos
python scripts/build_exe.py --clean --onefile
```

## 📊 Verificación Post-Build

### Checklist de QA
- [ ] El ejecutable inicia sin errores
- [ ] Login funciona con credenciales por defecto  
- [ ] Dashboard carga correctamente
- [ ] Todos los módulos son accesibles
- [ ] Base de datos se crea automáticamente
- [ ] No hay errores en logs
- [ ] Interfaz es responsive
- [ ] Tests pasan correctamente

### Tests de Integración
```bash
# Ejecutar tests completos antes de release
pytest tests/ -v --tb=short

# Verificar que todos pasen (87/87)
# Expected: 87 passed in X.XXs
```

## 🚀 Deploy Automático (Futuro)

### GitHub Actions
```yaml
# .github/workflows/build.yml
name: Build Release
on:
  push:
    tags: ['v*']
jobs:
  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install -e .[build]
      - run: python scripts/build_exe.py --onefile --windowed
      - uses: actions/upload-artifact@v3
        with:
          name: HEFEST-windows
          path: dist/HEFEST.exe
```

---

**📝 Nota**: Para más detalles técnicos, consulta la documentación en `docs/resumenes/`
