# -*- coding: utf-8 -*-
"""
Módulo de ventanas principales de la aplicación
"""
