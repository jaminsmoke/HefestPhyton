# -*- coding: utf-8 -*-
"""
Paquete principal de Hefest - Sistema Integral de Hostelería y Hospedería
"""
