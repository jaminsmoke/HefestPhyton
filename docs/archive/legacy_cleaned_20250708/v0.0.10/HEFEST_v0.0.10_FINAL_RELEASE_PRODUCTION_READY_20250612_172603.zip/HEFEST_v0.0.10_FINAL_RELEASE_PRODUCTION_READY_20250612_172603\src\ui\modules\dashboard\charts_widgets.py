"""
Widgets de gráficos para el dashboard de Hefest
"""

import logging
import numpy as np
import pyqtgraph as pg
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QToolTip)
from PyQt6.QtCore import Qt, pyqtSignal, QPoint
from PyQt6.QtGui import QColor, QPen, QLinearGradient, QPainter, QMouseEvent, QPaintEvent

from ...modern_components import ModernCard

logger = logging.getLogger(__name__)

# Configuración global de PyQtGraph
pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')


class TableMapWidget(QWidget):
    """Widget para mostrar un mapa visual de mesas"""
    
    mesa_clicked = pyqtSignal(int)  # Señal para cuando se hace clic en una mesa
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tables = []
        self.setMinimumHeight(220)
        self.hover_table = None
        self.setMouseTracking(True)  # Para detectar movimiento del ratón
    
    def set_tables(self, tables):
        """Establece los datos de las mesas"""
        # Convertir diccionarios a objetos con atributos si es necesario
        if tables and isinstance(tables[0], dict):
            from types import SimpleNamespace
            self.tables = [SimpleNamespace(**table) for table in tables]
        else:
            self.tables = tables
        self.update()
    
    def table_at_position(self, pos):
        """Determina qué mesa está en la posición indicada"""
        if not self.tables:
            return None
            
        # Tamaño y espaciado
        table_width = 60
        table_height = 60
        spacing = 10
        max_cols = 5
        
        for idx, table in enumerate(self.tables):
            col = idx % max_cols
            row = idx // max_cols
            
            # Calcular posición
            x = col * (table_width + spacing)
            y = row * (table_height + spacing)
            
            # Verificar si la posición está dentro de la mesa
            if (x <= pos.x() <= x + table_width and 
                y <= pos.y() <= y + table_height):                return table
                
        return None
    
    def mouseMoveEvent(self, a0):
        """Maneja el movimiento del ratón para mostrar información sobre las mesas"""
        if not a0:
            return
        table = self.table_at_position(a0.position())
        if table != self.hover_table:
            self.hover_table = table
            self.update()
            
            if table:
                # Mostrar tooltip con información detallada
                tooltip_text = f"""<b>Mesa {table.numero} - {table.zona}</b><br>
                                Estado: {table.estado.capitalize()}<br>
                                Capacidad: {table.capacidad} personas"""
                QToolTip.showText(a0.globalPosition().toPoint(), tooltip_text, self)
            else:
                QToolTip.hideText()

    def mousePressEvent(self, a0):
        """Maneja los clics en las mesas"""
        if not a0:
            return
        table = self.table_at_position(a0.position())
        if table and a0.button() == Qt.MouseButton.LeftButton:
            self.mesa_clicked.emit(table.id)

    def paintEvent(self, a0):
        """Dibuja las mesas según su estado"""
        if not self.tables:
            return
            
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Establecer colores por estado
        color_map = {
            'libre': QColor("#48BB78"),  # Verde
            'ocupada': QColor("#F56565"), # Rojo
            'reservada': QColor("#ECC94B")  # Amarillo
        }
        
        # Tamaño y espaciado
        table_width = 60
        table_height = 60
        spacing = 10
        max_cols = 5
        
        # Dibujar mesas
        col, row = 0, 0
        for table in self.tables:
            # Calcular posición
            x = col * (table_width + spacing)
            y = row * (table_height + spacing)
            
            # Seleccionar color según estado
            color = color_map.get(table.estado, QColor("#A0AEC0"))
            
            # Efectos de iluminación y sombreado
            gradient = QLinearGradient(x, y, x, y + table_height)
            base_color = color
            light_color = QColor(base_color)
            light_color.setAlpha(230)
            dark_color = QColor(base_color.darker(120))
            
            gradient.setColorAt(0, light_color)
            gradient.setColorAt(1, dark_color)
            
            # Dibujar mesa con gradiente
            painter.setPen(QPen(Qt.PenStyle.NoPen))
            painter.setBrush(gradient)
            painter.drawRoundedRect(x, y, table_width, table_height, 8, 8)
            
            # Borde para mesa en hover
            if table == self.hover_table:
                painter.setPen(QPen(QColor("#1f2937"), 3))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(x-2, y-2, table_width+4, table_height+4, 10, 10)
            
            # Texto del número de mesa
            painter.setPen(QPen(QColor("white"), 2))
            painter.drawText(x, y, table_width, table_height, 
                           Qt.AlignmentFlag.AlignCenter, str(table.numero))
            
            # Actualizar posición para la siguiente mesa
            col += 1
            if col >= max_cols:
                col = 0
                row += 1


class SalesChart(ModernCard):
    """Gráfico de ventas por hora con PyQtGraph"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ventas_por_hora = []
        self.setup_ui()
        self.load_sample_data()
        
    def setup_ui(self):
        """Configura la interfaz del gráfico"""
        self.setFixedHeight(280)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)

        # Crear gráfico directamente (sin header propio)
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('white')
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        
        # Estilo del gráfico
        self.plot_widget.getAxis('left').setPen(pg.mkPen(color='#6b7280', width=1))
        self.plot_widget.getAxis('bottom').setPen(pg.mkPen(color='#6b7280', width=1))
        self.plot_widget.getAxis('left').setTextPen(pg.mkPen(color='#6b7280'))
        self.plot_widget.getAxis('bottom').setTextPen(pg.mkPen(color='#6b7280'))
        
        layout.addWidget(self.plot_widget)

        # Total de ventas
        self.total_label = QLabel()
        self.total_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.total_label.setStyleSheet("font-weight: bold; color: #0f766e; margin-top: 10px;")
        layout.addWidget(self.total_label)
        
    def load_sample_data(self):
        """Carga datos de ejemplo para el gráfico"""
        import random
        
        horas = [f"{h:02d}:00" for h in range(8, 24)]  # 8:00 a 23:00
        ventas = [random.randint(50, 300) for _ in horas]
        
        self.ventas_por_hora = list(zip(horas, ventas))
        self.update_chart()
        
    def update_chart(self):
        """Actualiza el gráfico con los datos actuales"""
        if not self.ventas_por_hora:
            return
            
        # Limpiar gráfico anterior
        self.plot_widget.clear()
        
        # Datos
        horas = [h for h, _ in self.ventas_por_hora]
        ventas = [v for _, v in self.ventas_por_hora]
        x = np.arange(len(horas))
        
        # Dibujar barras
        bar_item = pg.BarGraphItem(
            x=x, 
            height=ventas,
            width=0.6,
            brush=pg.mkBrush('#3b82f6'),
            pen=pg.mkPen(None)
        )
        self.plot_widget.addItem(bar_item)
        
        # Configurar ejes
        self.plot_widget.getAxis('bottom').setTicks([[(i, h) for i, h in enumerate(horas)]])
        self.plot_widget.setLabel('left', 'Ventas (€)')
        
        # Actualizar total
        total_ventas = sum(ventas)
        self.total_label.setText(f"Total hoy: {total_ventas:.2f} €")
        
    def set_data(self, ventas_data):
        """Establece nuevos datos de ventas"""
        self.ventas_por_hora = ventas_data
        self.update_chart()
        
    def refresh_data(self):
        """Actualiza los datos del gráfico"""
        # Aquí podrías obtener datos reales de la base de datos
        self.load_sample_data()


class TableMapCard(ModernCard):
    """Tarjeta que contiene el mapa de mesas con leyenda"""
    
    mesa_clicked = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.table_map = TableMapWidget()
        self.setup_ui()
        self.load_sample_tables()
        
        # Conectar señales
        self.table_map.mesa_clicked.connect(self.mesa_clicked.emit)
        
    def setup_ui(self):
        """Configura la interfaz de la tarjeta"""
        self.setFixedHeight(280)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        
        # Mapa de mesas directo (sin header propio)
        layout.addWidget(self.table_map)
        
        # Leyenda de estados
        self.create_legend(layout)
        
    def create_legend(self, parent_layout):
        """Crea la leyenda de estados de las mesas"""
        legend_layout = QHBoxLayout()
        legend_layout.setSpacing(20)
        
        for status, color, text in [
            ("libre", "#48BB78", "Libre"),
            ("ocupada", "#F56565", "Ocupada"),
            ("reservada", "#ECC94B", "Reservada")
        ]:
            # Contenedor para cada estado
            status_container = QHBoxLayout()
            status_container.setSpacing(6)
            
            # Indicador de color
            status_indicator = QWidget()
            status_indicator.setFixedSize(14, 14)
            status_indicator.setStyleSheet(f"background-color: {color}; border-radius: 7px;")
            
            # Etiqueta de texto
            status_label = QLabel(text)
            status_label.setStyleSheet("font-size: 12px; color: #6b7280;")
            
            status_container.addWidget(status_indicator)
            status_container.addWidget(status_label)
            
            # Widget contenedor
            container_widget = QWidget()
            container_widget.setLayout(status_container)
            
            legend_layout.addWidget(container_widget)
            
        legend_layout.addStretch()
        
        # Widget contenedor para la leyenda
        legend_widget = QWidget()
        legend_widget.setLayout(legend_layout)
        parent_layout.addWidget(legend_widget)
        
    def load_sample_tables(self):
        """Carga mesas de ejemplo"""
        from types import SimpleNamespace
        
        # Crear mesas de ejemplo
        sample_tables = []
        estados = ['libre', 'ocupada', 'reservada']
        zonas = ['Terraza', 'Interior', 'VIP', 'Barra']
        
        for i in range(1, 16):  # 15 mesas
            table = SimpleNamespace()
            table.id = i
            table.numero = i
            table.zona = zonas[i % len(zonas)]
            table.estado = estados[i % len(estados)]
            table.capacidad = 2 + (i % 6)  # 2-8 personas
            sample_tables.append(table)
            
        self.table_map.set_tables(sample_tables)
        
    def set_tables(self, tables):
        """Establece los datos de las mesas"""
        self.table_map.set_tables(tables)
        
    def refresh_tables(self):
        """Actualiza los datos de las mesas"""
        # Aquí podrías obtener datos reales del servicio TPV
        self.load_sample_tables()
    
    def get_mesa_info(self, mesa_id):
        """Obtiene información detallada de una mesa"""
        for table in self.table_map.tables:
            if table.id == mesa_id:
                return {
                    "numero": table.numero,
                    "zona": table.zona,
                    "estado": table.estado,
                    "capacidad": table.capacidad,
                    "tiempo_ocupada": "45 min" if table.estado == "ocupada" else None,
                    "proxima_reserva": "14:30" if table.estado == "libre" else None
                }
        return None


class ChartsSection(QWidget):
    """Sección completa de gráficos del dashboard"""
    
    mesa_clicked = pyqtSignal(int)
    
    def __init__(self, dashboard_service=None, parent=None):
        super().__init__(parent)
        self.dashboard_service = dashboard_service
        self.setup_ui()
        
    def setup_ui(self):
        """Configura la interfaz de la sección de gráficos"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(20)
        
        # Header
        header = QLabel("Métricas Operativas")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #1f2937;")
        layout.addWidget(header)

        # Contenedor de gráficos
        charts_container = QWidget()
        charts_layout = QHBoxLayout(charts_container)
        charts_layout.setSpacing(20)
        charts_layout.setContentsMargins(0, 10, 0, 10)
        
        # Crear gráficos
        self.table_map_card = TableMapCard()
        self.sales_chart = SalesChart()
          # Conectar señales
        self.table_map_card.mesa_clicked.connect(self.mesa_clicked.emit)
        
        # Añadir al layout
        charts_layout.addWidget(self.table_map_card, 1)
        charts_layout.addWidget(self.sales_chart, 1)
        
        layout.addWidget(charts_container)
        
    def refresh_charts(self):
        """Actualiza todos los gráficos con datos reales"""
        if self.dashboard_service:
            try:
                # Actualizar datos de mesas
                mesas_data = self.dashboard_service.get_estado_mesas()
                
                # Verificar si es ChartData o lista de mesas directa
                if hasattr(mesas_data, 'data') and hasattr(mesas_data, 'labels'):
                    # Es un ChartData, crear mesas simuladas
                    self.table_map_card.refresh_tables()
                else:
                    # Es lista de mesas directa
                    self.set_tables_data(mesas_data)
                
                # Actualizar datos de ventas
                ventas_data = self.dashboard_service.get_ventas_por_hora()
                # Convertir a formato esperado por el gráfico
                ventas_formatted = [(v.hora, v.ventas) for v in ventas_data]
                self.set_sales_data(ventas_formatted)
                
            except Exception as e:
                logger.error(f"Error actualizando gráficos: {e}")
                # Fallback a datos simulados
                self.table_map_card.refresh_tables()
                self.sales_chart.refresh_data()
        else:
            # Sin servicio, usar datos simulados
            self.table_map_card.refresh_tables()
            self.sales_chart.refresh_data()
        
    def set_tables_data(self, tables):
        """Establece los datos de las mesas"""
        self.table_map_card.set_tables(tables)
        
    def set_sales_data(self, sales_data):
        """Establece los datos de ventas"""
        self.sales_chart.set_data(sales_data)
