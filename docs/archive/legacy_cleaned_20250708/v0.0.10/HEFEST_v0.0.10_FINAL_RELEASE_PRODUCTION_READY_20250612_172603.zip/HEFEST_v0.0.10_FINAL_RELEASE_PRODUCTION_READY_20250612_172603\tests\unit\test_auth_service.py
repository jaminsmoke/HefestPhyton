"""
Tests unitarios para el AuthService
==================================

Tests que validan el funcionamiento del servicio de autenticación,
incluyendo login básico, selector de usuarios y gestión de permisos.
"""

import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# Agregar src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from services.auth_service import AuthService, SessionInfo, AuthenticationError, PermissionError
from core.models import User, Role


class TestAuthService(unittest.TestCase):
    """Test case para AuthService"""
    
    def setUp(self):
        """Configuración antes de cada test"""
        self.auth_service = AuthService()
    
    def tearDown(self):
        """Limpieza después de cada test"""
        # Usar logout() en lugar de asignar directamente
        self.auth_service.logout()
    
    def test_initialization(self):
        """Test inicialización del AuthService"""
        self.assertIsNotNone(self.auth_service)
        self.assertIsNone(self.auth_service.current_session)
        self.assertIsNotNone(self.auth_service.default_users)
        self.assertEqual(len(self.auth_service.default_users), 3)
    
    def test_default_users_structure(self):
        """Test que los usuarios por defecto tienen la estructura correcta"""
        users = self.auth_service.users
        self.assertIsNotNone(users)
        self.assertEqual(len(users), 3)
        
        # Verificar que cada usuario tiene los campos necesarios
        for user in users:
            self.assertIsInstance(user, User)
            self.assertIsNotNone(user.id)
            self.assertIsNotNone(user.username)
            self.assertIsNotNone(user.name)
            self.assertIsNotNone(user.role)
            self.assertIsNotNone(user.password)
            self.assertTrue(user.is_active)
    
    def test_get_user_by_id(self):
        """Test obtener usuario por ID"""
        # Test usuario existente
        user = self.auth_service.get_user_by_id(1)
        self.assertIsNotNone(user)
        self.assertEqual(user.id, 1)
        self.assertEqual(user.username, "admin")
        
        # Test usuario inexistente
        user = self.auth_service.get_user_by_id(999)
        self.assertIsNone(user)
    
    def test_get_user_by_username(self):
        """Test obtener usuario por username"""
        # Test usuario existente
        user = self.auth_service.get_user_by_username("admin")
        self.assertIsNotNone(user)
        self.assertEqual(user.username, "admin")
        self.assertEqual(user.role, Role.ADMIN)
        
        # Test usuario inexistente
        user = self.auth_service.get_user_by_username("nonexistent")
        self.assertIsNone(user)
    
    def test_authenticate_basic_login_valid(self):
        """Test login básico con credenciales válidas"""
        self.assertTrue(self.auth_service.authenticate_basic_login("hefest", "admin"))
        self.assertTrue(self.auth_service.authenticate_basic_login("admin", "admin"))
        self.assertTrue(self.auth_service.authenticate_basic_login("usuario", "1234"))
    
    def test_authenticate_basic_login_invalid(self):
        """Test login básico con credenciales inválidas"""
        self.assertFalse(self.auth_service.authenticate_basic_login("wrong", "wrong"))
        self.assertFalse(self.auth_service.authenticate_basic_login("admin", "wrong"))
        self.assertFalse(self.auth_service.authenticate_basic_login("", ""))
    
    def test_login_valid_user_and_pin(self):
        """Test login con usuario y PIN válidos"""
        # Login con admin
        result = self.auth_service.login(1, "1234")
        self.assertTrue(result)
        self.assertIsNotNone(self.auth_service.current_session)
        self.assertEqual(self.auth_service.current_session.user_id, 1)
        self.assertEqual(self.auth_service.current_session.username, "admin")
        self.assertEqual(self.auth_service.current_session.role, Role.ADMIN)
    
    def test_login_invalid_user_id(self):
        """Test login con ID de usuario inválido"""
        result = self.auth_service.login(999, "1234")
        self.assertFalse(result)
        self.assertIsNone(self.auth_service.current_session)
    
    def test_login_invalid_pin(self):
        """Test login con PIN inválido"""
        result = self.auth_service.login(1, "wrong_pin")
        self.assertFalse(result)
        self.assertIsNone(self.auth_service.current_session)


if __name__ == '__main__':
    unittest.main()