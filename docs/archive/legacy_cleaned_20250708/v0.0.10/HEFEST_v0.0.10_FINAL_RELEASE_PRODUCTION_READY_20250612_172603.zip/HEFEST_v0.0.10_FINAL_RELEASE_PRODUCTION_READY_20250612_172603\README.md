# 🏨 HEFEST - Sistema Integral de Hostelería

<div align="center">

![Hefest Logo](assets/images/hefest_logo.png)

**Sistema Moderno de Gestión para Hostelería y Hospedería**

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![PyQt6](https://img.shields.io/badge/PyQt6-6.0+-green.svg)](https://www.riverbankcomputing.com/software/pyqt/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/Tests-87%2F87%20passing-brightgreen.svg)](tests/)
[![Version](https://img.shields.io/badge/Version-v0.0.10-blue.svg)](CHANGELOG.md)

[🚀 Instalación](#-instalación-rápida) • [📖 Documentación](docs/) • [🎯 Características](#-características-principales) • [📱 Capturas](#-capturas-de-pantalla) • [🔧 Desarrollo](#-desarrollo)

</div>

---

## 🎯 ¿Qué es HEFEST?

**HEFEST** es un sistema integral de gestión moderno diseñado específicamente para negocios de **hostelería** (restaurantes, bares, cafeterías) y **hospedería** (hoteles, hostales, apartamentos). 

### ✨ **Características Distintivas**
- **🎨 Interfaz moderna** con animaciones fluidas y diseño profesional
- **📊 Dashboard en tiempo real** con métricas operativas inteligentes  
- **🔐 Sistema de roles** (Admin, Manager, Employee) con permisos granulares
- **📱 Diseño responsive** adaptable a diferentes resoluciones
- **⚡ Alto rendimiento** optimizado para uso profesional
- **🧪 100% testeado** con 87/87 tests pasando

---

## 🚀 Instalación Rápida

### **Opción 1: Instalación desde Código (Recomendada para desarrollo)**

```bash
# 1. Clonar el repositorio
git clone https://github.com/usuario/hefest.git
cd hefest

# 2. Crear entorno virtual
python -m venv .venv
.venv\Scripts\activate  # Windows
# source .venv/bin/activate  # Linux/Mac

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Ejecutar aplicación
python main.py
```

### **Opción 2: Instalación como Paquete**

```bash
# Instalar directamente desde el proyecto
pip install -e .

# Ejecutar desde cualquier lugar
hefest
```

### **Opción 3: Ejecutable Windows (.exe)**

```bash
# Descargar desde releases
# https://github.com/usuario/hefest/releases/latest
# Ejecutar: hefest-v0.0.10-setup.exe
```

### **🔑 Credenciales por Defecto**

| Usuario | Contraseña | Rol | Descripción |
|---------|------------|-----|-------------|
| `admin` | `admin123` | Admin | Acceso completo al sistema |
| `manager` | `manager123` | Manager | Gestión operativa sin configuración |
| `employee` | `employee123` | Employee | Acceso a TPV y operaciones básicas |

---

## 🎯 Características Principales

<table>
<tr>
<td width="50%">

### 🏠 **Dashboard Inteligente**
- **Métricas en tiempo real**: Ventas, ocupación, inventario
- **Alertas automáticas**: Stock bajo, reservas pendientes
- **Gráficos interactivos**: Ventas por hora, estado de mesas
- **KPIs dinámicos**: Ticket promedio, rotación de mesas

### 💰 **Terminal TPV**
- **Gestión de comandas** rápida e intuitiva
- **División de cuentas** flexible
- **Impresión de tickets** automática
- **Productos favoritos** de acceso rápido

### 🏨 **Módulo Hospedería**
- **Check-in/Check-out** simplificado
- **Gestión de habitaciones** en tiempo real
- **Control de limpieza** y mantenimiento
- **Calendario de reservas** visual

</td>
<td width="50%">

### 📦 **Gestión de Inventario**
- **Control de stock** con alertas automáticas
- **Búsqueda inteligente** de productos
- **Gestión de proveedores** completa
- **Informes de rotación** de inventario

### 👥 **Sistema de Usuarios**
- **Roles jerárquicos**: Admin → Manager → Employee
- **Permisos granulares** por módulo
- **Auditoría completa** de acciones
- **Sesiones seguras** con autenticación

### 📊 **Reportes y Análisis**
- **Informes automáticos** de ventas
- **Análisis de tendencias** de consumo
- **Exportación** a Excel/PDF
- **Datos históricos** completos

</td>
</tr>
</table>

---

## 📱 Capturas de Pantalla

<table>
<tr>
<td align="center" width="33%">
<img src="assets/images/login_screen.png" width="250px" alt="Pantalla Login">
<br><b>🔐 Login Moderno</b>
<br><sub>Autenticación segura con efectos visuales</sub>
</td>
<td align="center" width="33%">
<img src="assets/images/dashboard_main.png" width="250px" alt="Dashboard Principal">
<br><b>📊 Dashboard Principal</b>
<br><sub>Métricas en tiempo real y alertas</sub>
</td>
<td align="center" width="33%">
<img src="assets/images/tpv_module.png" width="250px" alt="Módulo TPV">
<br><b>💰 Terminal TPV</b>
<br><sub>Punto de venta intuitivo</sub>
</td>
</tr>
<tr>
<td align="center" width="33%">
<img src="assets/images/inventory_module.png" width="250px" alt="Módulo Inventario">
<br><b>📦 Gestión Inventario</b>
<br><sub>Control completo de stock</sub>
</td>
<td align="center" width="33%">
<img src="assets/images/hospederia_module.png" width="250px" alt="Módulo Hospedería">
<br><b>🏨 Sistema Hospedería</b>
<br><sub>Gestión de habitaciones</sub>
</td>
<td align="center" width="33%">
<img src="assets/images/users_module.png" width="250px" alt="Gestión Usuarios">
<br><b>👥 Gestión Usuarios</b>
<br><sub>Administración de permisos</sub>
</td>
</tr>
</table>

---

## 🏗️ Arquitectura del Sistema

### **📁 Estructura del Proyecto**

```
hefest/
├── 📱 src/                          # Código fuente principal
│   ├── 🧠 core/                     # Lógica de negocio central
│   ├── 🔌 services/                 # Servicios de aplicación
│   ├── 🎨 ui/                       # Interfaz de usuario
│   │   ├── 🧩 components/           # Componentes reutilizables
│   │   ├── 📋 modules/              # Módulos principales
│   │   │   ├── dashboard/           # Dashboard modular
│   │   │   ├── tpv/                 # Terminal TPV
│   │   │   ├── inventario/          # Gestión inventario
│   │   │   └── hospederia/          # Sistema hospedería
│   │   └── 🪟 dialogs/              # Ventanas de diálogo
│   └── 🛠️ utils/                    # Utilidades y helpers
├── 🗃️ data/                         # Gestión de base de datos
├── 🧪 tests/                        # Suite de tests (87/87 ✅)
├── 📚 docs/                         # Documentación técnica
├── 📝 logs/                         # Archivos de registro
├── ⚙️ config/                       # Configuraciones
├── 🎨 assets/                       # Recursos gráficos
└── 📦 scripts/                      # Scripts de automatización
```

### **🔧 Stack Tecnológico**

| Capa | Tecnologías | Descripción |
|------|-------------|-------------|
| **🎨 Frontend** | PyQt6, QSS, Animaciones | Interfaz moderna y responsive |
| **🧠 Backend** | Python 3.13, SQLite | Lógica de negocio robusta |
| **🗃️ Base de Datos** | SQLite (local) | Almacenamiento eficiente |
| **🧪 Testing** | pytest, unittest | 87 tests automatizados |
| **📦 Empaquetado** | setuptools, PyInstaller | Distribución multiplataforma |
| **🎨 UI/UX** | Modern CSS, Glassmorphism | Diseño profesional |

---

## 📖 Guía de Uso

### **🚀 Inicio Rápido**

1. **Ejecutar la aplicación**:
   ```bash
   # Opción 1: Archivo batch (Windows)
   ejecutar_hefest.bat
   
   # Opción 2: Python directo
   python main.py
   
   # Opción 3: Como paquete instalado
   hefest
   ```

2. **Iniciar sesión**:
   - Usuario: `admin` / Contraseña: `admin123`
   - El sistema te llevará al dashboard principal

3. **Explorar módulos**:
   - 🏠 **Dashboard**: Vista general del negocio
   - 💰 **TPV**: Realizar ventas y gestionar comandas
   - 📦 **Inventario**: Controlar stock y productos
   - 🏨 **Hospedería**: Gestionar habitaciones (si aplica)
   - 👥 **Usuarios**: Administrar personal (solo Admin)

### **🎯 Casos de Uso Típicos**

<details>
<summary><b>📊 Consultar métricas diarias</b></summary>

1. Acceder al **Dashboard**
2. Revisar **KPIs principales**: ventas del día, ocupación, ticket promedio
3. Verificar **alertas automáticas**: stock bajo, reservas pendientes
4. Analizar **gráfico de ventas** por hora
</details>

<details>
<summary><b>💰 Procesar una venta</b></summary>

1. Ir al módulo **TPV**
2. Seleccionar **productos** del catálogo
3. Ajustar **cantidades** si es necesario
4. **Finalizar venta** e imprimir ticket
</details>

<details>
<summary><b>📦 Gestionar inventario</b></summary>

1. Acceder al módulo **Inventario**
2. **Buscar productos** por nombre o categoría
3. **Actualizar stock** manualmente o ver alertas
4. **Gestionar proveedores** y pedidos
</details>

---

## 🔧 Desarrollo

### **📋 Requisitos del Sistema**

| Componente | Versión Mínima | Recomendada |
|------------|----------------|-------------|
| **Python** | 3.10+ | 3.13+ |
| **Memoria RAM** | 2GB | 4GB+ |
| **Espacio en Disco** | 500MB | 1GB+ |
| **SO** | Windows 10+ | Windows 11+ |
| **Resolución** | 1024x768 | 1920x1080+ |

### **🛠️ Configuración de Desarrollo**

```bash
# 1. Clonar y configurar
git clone https://github.com/usuario/hefest.git
cd hefest

# 2. Entorno virtual
python -m venv .venv
.venv\Scripts\activate

# 3. Dependencias de desarrollo
pip install -e .[dev]

# 4. Ejecutar tests
python -m pytest tests/ -v

# 5. Formatear código
python -m black src/ tests/

# 6. Verificar base de datos
python data/init_db.py
```

### **🧪 Testing**

```bash
# Ejecutar todos los tests
pytest tests/ -v

# Tests específicos
pytest tests/unit/test_auth_service.py -v
pytest tests/integration/ -v

# Cobertura de código
pytest --cov=src tests/
```

### **📦 Empaquetado**

```bash
# Crear ejecutable Windows
python -m PyInstaller --windowed --onefile main.py

# Crear instalador con Inno Setup
iscc setup.iss

# Crear paquete Python
python -m build
pip install dist/hefest-0.0.10.tar.gz
```

---

## 📚 Documentación Técnica

### **📄 Documentos Principales**

- 📋 **[CHANGELOG.md](CHANGELOG.md)**: Historial completo de cambios
- 🏗️ **[docs/resumenes/](docs/resumenes/)**: Documentación técnica por versiones
- 🧪 **[tests/](tests/)**: Suite completa de tests automatizados
- ⚙️ **[pyproject.toml](pyproject.toml)**: Configuración del proyecto

### **🔗 Enlaces Útiles**

- **📊 Estado del Proyecto**: [v0.0.10 - COMPLETADO](docs/resumenes/v0.0.10/PROYECTO_FINALIZADO_v0.0.10_20250612.md)
- **🧪 Corrección de Tests**: [87/87 tests passing](docs/resumenes/v0.0.10/CORRECCION_TESTS_v0.0.10_20250612_COMPLETO.md)
- **📁 Organización**: [Documentación reorganizada](docs/resumenes/v0.0.10/ORGANIZACION_DOCUMENTACION_v0.0.10_20250612.md)

---

## 🤝 Contribución

### **🚀 Cómo Contribuir**

1. **Fork** el repositorio
2. **Crear rama**: `git checkout -b feature/nueva-funcionalidad`
3. **Commit cambios**: `git commit -m 'feat: añadir nueva funcionalidad'`
4. **Push rama**: `git push origin feature/nueva-funcionalidad`
5. **Crear Pull Request**

### **📝 Estándares de Código**

- **Formato**: Black para Python
- **Linting**: flake8 + mypy
- **Tests**: pytest con cobertura >90%
- **Commits**: Conventional Commits
- **Documentación**: Docstrings en español

---

## 🏆 Estado del Proyecto

### **✅ Versión Actual: v0.0.10**

| Componente | Estado | Tests | Cobertura |
|------------|--------|-------|-----------|
| 🔐 **Autenticación** | ✅ Completado | 9/9 | 100% |
| 🗃️ **Base de Datos** | ✅ Completado | 11/11 | 100% |
| 📦 **Inventario** | ✅ Completado | 9/9 | 100% |
| 🧾 **Modelos** | ✅ Completado | 17/17 | 100% |
| 🎨 **UI Components** | ✅ Completado | 42/42 | 100% |
| 🔗 **Integración** | ✅ Completado | 3/3 | 100% |
| **🎯 TOTAL** | **✅ LISTO** | **87/87** | **100%** |

### **🎯 Próximas Versiones**

- **v0.1.0**: Módulo de reportes avanzados
- **v0.2.0**: API REST para integración externa
- **v0.3.0**: App móvil de monitoreo
- **v1.0.0**: Release de producción

---

## 📄 Licencia

Este proyecto está licenciado bajo la **Licencia MIT**. Consulta el archivo [LICENSE](LICENSE) para más detalles.

```
MIT License

Copyright (c) 2025 Hefest Development Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
```

---

## 📞 Soporte y Contacto

<div align="center">

### **¿Necesitas ayuda?**

💬 **Issues**: [GitHub Issues](https://github.com/usuario/hefest/issues)  
📧 **Email**: dev@hefest.com  
📚 **Wiki**: [Documentación Completa](https://github.com/usuario/hefest/wiki)  
🐛 **Bugs**: [Reportar Bug](https://github.com/usuario/hefest/issues/new?template=bug_report.md)  
💡 **Features**: [Solicitar Feature](https://github.com/usuario/hefest/issues/new?template=feature_request.md)  

---

**⭐ Si te gusta HEFEST, ¡dale una estrella en GitHub!**

[![GitHub stars](https://img.shields.io/github/stars/usuario/hefest.svg?style=social&label=Star)](https://github.com/usuario/hefest)
[![GitHub forks](https://img.shields.io/github/forks/usuario/hefest.svg?style=social&label=Fork)](https://github.com/usuario/hefest/fork)

</div>

---

<div align="center">

**🏨 HEFEST v0.0.10 - Sistema Integral de Hostelería**

*Desarrollado con ❤️ para modernizar la gestión hostelera*

**© 2025 Hefest Development Team - Todos los derechos reservados**

</div>
